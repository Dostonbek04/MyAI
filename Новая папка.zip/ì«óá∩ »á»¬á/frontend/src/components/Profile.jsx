import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import '../style/Profile.css';
import * as bootstrap from 'bootstrap';

const Profile = () => {
    const [user, setUser] = useState({
        username: '',
        email: '',
        balance: 0,
        is_email_verified: false,
        profile: {
            image: { url: '/media/default/default_profile.png' },
            email_notifications: false,
            system_notifications: false,
            bio: '',
        },
    });
    const [balance, setBalance] = useState(0);
    const [presentations, setPresentations] = useState([]);
    const [notifications, setNotifications] = useState([]);
    const [notificationCount, setNotificationCount] = useState(0);
    const [searchQuery, setSearchQuery] = useState('');
    const [showSidebar, setShowSidebar] = useState(false);
    const [verificationCode, setVerificationCode] = useState('');
    const [timer, setTimer] = useState(15 * 60); // 15 daqiqa
    const [isTimerActive, setIsTimerActive] = useState(false);
    const navigate = useNavigate();

    // Foydalanuvchi ma'lumotlari, balans va taqdimotlarni olish
    useEffect(() => {
        const fetchUserData = async () => {
            try {
                const userResponse = await axios.get('/users/profile/', {
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'Authorization': `Bearer ${localStorage.getItem('token')}`,
                    },
                });
                setUser(userResponse.data.user);
                setBalance(userResponse.data.balance || 0);

                const presentationsResponse = await axios.get('/presentations/list/', {
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'Authorization': `Bearer ${localStorage.getItem('token')}`,
                    },
                });
                setPresentations(presentationsResponse.data.presentations || []);

                // Feedback modal logikasi
                const presentationCount = presentationsResponse.data.presentations.length;
                if (presentationCount > 0 && presentationCount % 5 === 0) {
                    const feedbackLater = localStorage.getItem('feedbackLater');
                    if (!feedbackLater) {
                        const feedbackModal = new bootstrap.Modal(document.getElementById('feedbackModal'), {
                            backdrop: 'static',
                            keyboard: false,
                        });
                        feedbackModal.show();
                    }
                }
            } catch (err) {
                console.error('Profilni olishda xato:', err);
            }
        };

        fetchUserData();

        // Dark/Light tema sinxronizatsiyasi
        const currentTheme = localStorage.getItem('theme') || 'light';
        document.documentElement.setAttribute('data-theme', currentTheme);

        // Tooltip'larni faollashtirish
        const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
        const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));

        // Taqdimotlar konteynerining balandligini sozlash
        adjustPresentationsContainerHeight();
        window.addEventListener('resize', adjustPresentationsContainerHeight);

        return () => {
            window.removeEventListener('resize', adjustPresentationsContainerHeight);
        };
    }, []);

    // Taymer logikasi
    useEffect(() => {
        let timerInterval;
        if (isTimerActive && timer > 0) {
            timerInterval = setInterval(() => {
                setTimer(prev => prev - 1);
            }, 1000);
        } else if (timer <= 0) {
            setIsTimerActive(false);
        }
        return () => clearInterval(timerInterval);
    }, [isTimerActive, timer]);

    const startVerificationTimer = () => {
        setTimer(15 * 60);
        setIsTimerActive(true);
    };

    // CSRF tokenni olish
    const getCsrfToken = () => {
        const name = 'csrftoken';
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    };

    // Email tasdiqlash
    const handleVerifyEmail = async (e, isMobile = false) => {
        e.preventDefault();
        try {
            const response = await axios.get('/users/resend_verification_email/', {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`,
                },
            });
            if (response.data.success) {
                const verifyEmailModal = new bootstrap.Modal(document.getElementById('verifyEmailModal'), {
                    backdrop: 'static',
                    keyboard: false,
                });
                verifyEmailModal.show();
                startVerificationTimer();
            } else {
                alert(response.data.message || 'Xatolik yuz berdi. Iltimos, qayta urinib ko‘ring.');
            }
        } catch (err) {
            console.error('Email tasdiqlashda xato:', err);
            alert('Xatolik yuz berdi. Iltimos, qayta urinib ko‘ring.');
        }
    };

    // Kod tasdiqlash
    const handleVerifyCode = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post(
                '/users/verify_code/',
                { code: verificationCode },
                {
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRFToken': getCsrfToken(),
                        'Authorization': `Bearer ${localStorage.getItem('token')}`,
                    },
                }
            );
            if (response.data.success) {
                setUser({ ...user, is_email_verified: true });
                alert(response.data.message);
                bootstrap.Modal.getInstance(document.getElementById('verifyEmailModal')).hide();
            } else {
                alert(response.data.message || 'Kod noto‘g‘ri. Iltimos, qayta urinib ko‘ring.');
            }
        } catch (err) {
            console.error('Kod tasdiqlashda xato:', err);
            alert('Xatolik yuz berdi. Iltimos, qayta urinib ko‘ring.');
        }
    };

    // Qayta kod yuborish
    const handleResendCode = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.get('/users/resend_verification_email/', {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`,
                },
            });
            if (response.data.success) {
                startVerificationTimer();
            } else {
                alert(response.data.message || 'Xatolik yuz berdi. Iltimos, qayta urinib ko‘ring.');
            }
        } catch (err) {
            console.error('Kod qayta yuborishda xato:', err);
            alert('Xatolik yuz berdi. Iltimos, qayta urinib ko‘ring.');
        }
    };

    // Taqdimotlarni qidirish
    const handleSearch = (e) => {
        setSearchQuery(e.target.value.toLowerCase());
    };

    const filteredPresentations = presentations.filter((presentation) =>
        presentation.title.toLowerCase().includes(searchQuery)
    );

    // Taqdimotni yuklab olish
    const handleDownload = async (presentationId, title) => {
        try {
            const response = await axios.get(`/presentations/download/${presentationId}/`, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`,
                },
                responseType: 'blob',
            });
            const blob = response.data;
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `${title}.pptx`;
            document.body.appendChild(a);
            a.click();
            a.remove();
        } catch (err) {
            console.error('Fayl yuklab olishda xato:', err);
            alert('Fayl yuklab olishda xato yuz berdi!');
        }
    };

    // Taqdimotni o‘chirish
    const handleDeletePresentation = async (presentationId) => {
        if (!window.confirm('Taqdimotni o‘chirishni tasdiqlaysizmi?')) return;

        try {
            const response = await axios.get(`/presentations/delete_presentation/${presentationId}/`, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`,
                },
            });
            if (response.data.success) {
                setPresentations(presentations.filter((p) => p.id !== presentationId));
                alert(response.data.message);
            } else {
                alert('Taqdimotni o‘chirishda xato yuz berdi!');
            }
        } catch (err) {
            console.error('Taqdimotni o‘chirishda xato:', err);
            alert('Taqdimotni o‘chirishda xato yuz berdi!');
        }
    };

    // Bildirishnomalarni olish
    const fetchNotifications = async () => {
        try {
            const response = await axios.get('/users/get_notifications/', {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`,
                },
            });
            setNotifications(response.data.notifications || []);
            setNotificationCount(response.data.notifications.length);
        } catch (err) {
            console.error('Bildirishnomalarni olishda xato:', err);
            setNotifications([]);
            setNotificationCount(0);
        }
    };

    // Sozlamalarni saqlash
    const saveSettings = async () => {
        try {
            const response = await axios.post(
                '/users/save_notification_settings/',
                {
                    email_notifications: user.profile.email_notifications,
                    system_notifications: user.profile.system_notifications,
                },
                {
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRFToken': getCsrfToken(),
                        'Authorization': `Bearer ${localStorage.getItem('token')}`,
                    },
                }
            );
            if (response.data.success) {
                alert(response.data.message);
                bootstrap.Modal.getInstance(document.getElementById('settingsModal')).hide();
            } else {
                alert('Sozlamalarni saqlashda xato yuz berdi!');
            }
        } catch (err) {
            console.error('Sozlamalarni saqlashda xato:', err);
            alert('Sozlamalarni saqlashda xato yuz berdi!');
        }
    };

    // Profilni o‘chirish
    const deleteProfile = async () => {
        if (!window.confirm('Haqiqatan ham profilingizni o‘chirishni xohlaysizmi? Bu amalni qaytarib bo‘lmaydi!')) return;

        try {
            const response = await axios.post(
                '/users/delete_profile/',
                {},
                {
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRFToken': getCsrfToken(),
                        'Authorization': `Bearer ${localStorage.getItem('token')}`,
                    },
                }
            );
            if (response.data.success) {
                alert(response.data.message);
                navigate('/');
            } else {
                alert('Profilingizni o‘chirishda xato yuz berdi: ' + response.data.message);
            }
        } catch (err) {
            console.error('Profilingizni o‘chirishda xato:', err);
            alert('Profilingizni o‘chirishda xato yuz berdi!');
        }
    };

    // Feedback modalni yashirish
    const setFeedbackLater = () => {
        localStorage.setItem('feedbackLater', 'true');
        bootstrap.Modal.getInstance(document.getElementById('feedbackModal')).hide();
    };

    // Taqdimotlar konteynerining balandligini sozlash
    const adjustPresentationsContainerHeight = () => {
        const mainContent = document.querySelector('.main-content');
        const presentationsContainer = document.querySelector('.presentations-container');
        const headerSection = document.querySelector('.d-flex.justify-content-between');
        const hrElement = document.querySelector('hr');
        const searchSection = document.querySelector('.mb-4');

        if (!mainContent || !presentationsContainer || !headerSection || !hrElement || !searchSection) return;

        const windowHeight = window.innerHeight;
        const headerHeight = headerSection.getBoundingClientRect().height;
        const hrHeight = hrElement.getBoundingClientRect().height;
        const searchHeight = searchSection.getBoundingClientRect().height;
        const padding = 40;

        const availableHeight = windowHeight - headerHeight - hrHeight - searchHeight - padding;
        presentationsContainer.style.maxHeight = `${availableHeight}px`;
    };

    if (!user) return <div>Yuklanmoqda...</div>;

    return (
        <div className="d-flex">
            {/* Sidebar */}
            <div
                className={`sidebar border-end vh-100 position-fixed d-md-block collapse ${showSidebar ? 'show' : ''}`}
                id="sidebarMenu"
                style={{ width: '250px', zIndex: 1000 }}
            >
                <div className="p-4 text-center">
                    <img
                        src={user.profile.image.url || '/media/default/default_profile.png'}
                        alt="Profil rasmi"
                        className="rounded-circle mb-3"
                        width="80"
                        height="80"
                    />
                    <h4 className="fw-bold">{user.username}</h4>
                    <p className="text-muted">{user.email}</p>
                    <Link to="/users/edit-profile" className="btn btn-primary w-100 mt-2">
                        Profilni tahrirlash
                    </Link>
                </div>
                <div className="list-group list-group-flush">
                    <a
                        href="#"
                        className="list-group-item list-group-item-action"
                        data-bs-toggle="modal"
                        data-bs-target="#settingsModal"
                    >
                        Sozlamalar
                    </a>
                    <a href="#" className="list-group-item list-group-item-action">
                        Xavfsizlik
                    </a>
                    <a href="#" className="list-group-item list-group-item-action">
                        Yordam
                    </a>
                    <Link to="/payments/profile-payments" className="list-group-item list-group-item-action">
                        To'lov Tarixi
                    </Link>
                    <Link to="/feedback/feedback-view" className="list-group-item list-group-item-action">
                        Fikrlar
                    </Link>
                    <Link to="/privacy-policy" className="list-group-item list-group-item-action">
                        Maxfiylik Siyosati
                    </Link>
                    <Link to="/terms" className="list-group-item list-group-item-action">
                        Foydalanish Shartlari
                    </Link>
                    {!user.is_email_verified && (
                        <a
                            href="#"
                            className="list-group-item list-group-item-action text-primary"
                            id="verifyEmailTrigger"
                            onClick={(e) => handleVerifyEmail(e)}
                        >
                            <i className="fa-solid fa-envelope me-1"></i> Emailni tasdiqlash
                        </a>
                    )}
                    <form
                        id="logout-form"
                        onSubmit={(e) => {
                            e.preventDefault();
                            navigate('/logout');
                        }}
                        className="list-group-item list-group-item-action"
                    >
                        <a
                            href="#"
                            onClick={() => document.getElementById('logout-form').submit()}
                            className="text-decoration-none text-danger"
                        >
                            <i className="fa-solid fa-right-from-bracket"></i> Akkauntdan Chiqish
                        </a>
                    </form>
                </div>
            </div>

            {/* Asosiy kontent */}
            <div className="main-content flex-grow-1" style={{ marginLeft: '250px', padding: '20px' }}>
                <div className="d-flex justify-content-between align-items-center mb-4">
                    <div className="d-flex align-items-center">
                        <button
                            className="navbar-toggler d-md-none me-3"
                            type="button"
                            onClick={() => setShowSidebar(!showSidebar)}
                            aria-controls="sidebarMenu"
                            aria-expanded={showSidebar}
                            aria-label="Toggle navigation"
                        >
                            <span className="navbar-toggler-icon">
                                <span className="line line-1"></span>
                                <span className="line line-2"></span>
                                <span className="line line-3"></span>
                            </span>
                        </button>
                        <h2 className="main fw-bold mb-0">PresentlyAI</h2>
                    </div>
                    <div className="d-flex align-items-center gap-3">
                        <div className="d-flex align-items-center gap-2">
                            <div
                                className="d-none d-md-flex align-items-center"
                                data-bs-toggle="tooltip"
                                data-bs-placement="top"
                                title="Balans"
                            >
                                <i className="fa-solid fa-wallet text-success me-1"></i>
                                <span className="fw-bold text-success">Balans: ${balance} UZS</span>
                            </div>
                            <div
                                className="d-flex d-md-none align-items-center"
                                data-bs-toggle="tooltip"
                                data-bs-placement="top"
                                title={`Balans: $${balance}`}
                            >
                                <i className="fa-solid fa-wallet text-success me-1"></i>
                                <span className="fw-bold text-success">${balance} UZS</span>
                            </div>
                            <Link
                                to="/payments/request-payment"
                                className="btn btn-success btn-sm"
                                data-bs-toggle="tooltip"
                                data-bs-placement="top"
                                title="To'lov qilish"
                            >
                                <i className="fa-solid fa-credit-card"></i>
                            </Link>
                        </div>
                        <div className="d-flex align-items-center">
                            {user.is_email_verified ? (
                                <>
                                    <div
                                        className="d-none d-md-flex align-items-center"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="top"
                                        title="Email tasdiqlangan"
                                    >
                                        <i className="fa-solid fa-check-circle text-success me-1"></i>
                                        <span className="text-success">Email tasdiqlangan</span>
                                    </div>
                                    <div
                                        className="d-flex d-md-none align-items-center"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="top"
                                        title="Email tasdiqlangan"
                                    >
                                        <i className="fa-solid fa-check-circle text-success"></i>
                                    </div>
                                </>
                            ) : (
                                <>
                                    <div
                                        className="d-none d-md-flex align-items-center"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="top"
                                        title="Email tasdiqlanmagan"
                                    >
                                        <i className="fa-solid fa-times-circle text-danger me-1"></i>
                                        <span className="text-danger">Email tasdiqlanmagan</span>
                                    </div>
                                    <div
                                        className="d-flex d-md-none align-items-center"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="top"
                                        title="Email tasdiqlanmagan"
                                    >
                                        <a
                                            href="#"
                                            id="verifyEmailTriggerMobile"
                                            onClick={(e) => handleVerifyEmail(e, true)}
                                        >
                                            <i className="fa-solid fa-times-circle text-danger"></i>
                                        </a>
                                    </div>
                                </>
                            )}
                        </div>
                        <div className="d-flex align-items-center position-relative notification-container">
                            <i
                                className="fas fa-bell fa-lg"
                                style={{ cursor: 'pointer' }}
                                data-bs-toggle="modal"
                                data-bs-target="#notificationsModal"
                                data-bs-toggle="tooltip"
                                data-bs-placement="top"
                                title="Bildirishnomalar"
                                onClick={fetchNotifications}
                            ></i>
                            <span
                                id="notificationCount"
                                className="badge badge-danger position-absolute"
                                style={{ top: '-15px', right: '-10px' }}
                            >
                                {notificationCount}
                            </span>
                        </div>
                        <Link to="/presentations/create-presentation" className="btn btn-primary btn-sm">
                            <span className="d-none d-md-inline">Yangi Taqdimot Yaratish</span>
                            <span className="d-md-none">Yaratish</span>
                        </Link>
                    </div>
                </div>

                {/* Bildirishnoma Modal */}
                <div
                    className="modal fade notification-modal"
                    id="notificationsModal"
                    tabIndex="-1"
                    aria-labelledby="notificationsModalLabel"
                    aria-hidden="true"
                >
                    <div className="modal-dialog">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title" id="notificationsModalLabel">
                                    Bildirishnomalar
                                </h5>
                                <button
                                    type="button"
                                    className="btn-close"
                                    data-bs-dismiss="modal"
                                    aria-label="Close"
                                ></button>
                            </div>
                            <div className="modal-body" id="notificationsBody">
                                {notifications.length > 0 ? (
                                    notifications.map((notification, index) => (
                                        <div key={index} className="notification-item mb-2">
                                            <p className="mb-1">{notification.message}</p>
                                            <small className="text-muted">{notification.created_at}</small>
                                            <hr className="my-1" />
                                        </div>
                                    ))
                                ) : (
                                    <p>Hozircha yangi bildirishnomalar yo‘q.</p>
                                )}
                            </div>
                            <div className="modal-footer">
                                <button
                                    type="button"
                                    className="btn btn-secondary"
                                    data-bs-dismiss="modal"
                                >
                                    Yopish
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <hr className="my-4 border-2 border-primary" />

                {/* Mening Taqdimotlarim */}
                <div className="card border-0 rounded-lg">
                    <div className="card-body d-flex flex-column">
                        <div className="mb-4">
                            <div className="input-group">
                                <input
                                    type="text"
                                    id="searchInput"
                                    className="form-control"
                                    placeholder="Taqdimot sarlavhasini qidiring..."
                                    value={searchQuery}
                                    onChange={handleSearch}
                                    aria-label="Qidiruv"
                                />
                                <span className="input-group-text">
                                    <i className="fa-solid fa-search"></i>
                                </span>
                            </div>
                        </div>
                        <div className="presentations-container flex-grow-1" style={{ overflowY: 'auto' }}>
                            <div className="row" id="presentationsList">
                                {filteredPresentations.length > 0 ? (
                                    filteredPresentations.map((presentation) => (
                                        <div
                                            key={presentation.id}
                                            className="col-md-3 col-sm-6 mb-4 presentation-item"
                                            data-presentation-id={presentation.id}
                                        >
                                            <div className="card presentation-card shadow-lg border-0 rounded-lg">
                                                <div className="card-img-top text-center">
                                                    <img
                                                        src={
                                                            presentation.preview_image?.url ||
                                                            presentation.preview_image ||
                                                            '/media/default/default_presentation_preview.png'
                                                        }
                                                        alt={`${presentation.title} birinchi varag'i`}
                                                        className="img-fluid rounded-top"
                                                        style={{ maxHeight: '140px', objectFit: 'cover' }}
                                                    />
                                                </div>
                                                <div className="card-body text-center py-2">
                                                    <h5
                                                        className="card-title fw-bold mb-0 presentation-title"
                                                        data-bs-toggle="tooltip"
                                                        data-bs-placement="top"
                                                        title={presentation.title}
                                                    >
                                                        {presentation.title}
                                                    </h5>
                                                    <p className="text-muted mb-1">
                                                        Yaratilgan: {new Date(presentation.created_at).toLocaleString()}
                                                    </p>
                                                    <p className="text-muted mb-1">
                                                        Egasi: {presentation.user?.username || user.username}
                                                    </p>
                                                    {presentation.updated_at && (
                                                        <p className="text-muted mb-1">
                                                            🔄 Tahrir: {new Date(presentation.updated_at).toLocaleString()}
                                                        </p>
                                                    )}
                                                    <hr className="my-2" />
                                                    <div className="d-flex justify-content-center flex-wrap gap-2 mb-2">
                                                        <a
                                                            className="btn btn-outline-info btn-sm"
                                                            data-bs-toggle="tooltip"
                                                            data-bs-placement="top"
                                                            title="Ko‘rish"
                                                        >
                                                            <i className="fa-solid fa-eye"></i>
                                                        </a>
                                                        {presentation.file?.url || presentation.file ? (
                                                            <a
                                                                href={presentation.file.url || presentation.file}
                                                                onClick={(e) => {
                                                                    e.preventDefault();
                                                                    handleDownload(presentation.id, presentation.title);
                                                                }}
                                                                className="btn btn-outline-primary btn-sm"
                                                                data-bs-toggle="tooltip"
                                                                data-bs-placement="top"
                                                                title="Yuklab olish"
                                                            >
                                                                <i className="fa-solid fa-download"></i>
                                                            </a>
                                                        ) : (
                                                            <button
                                                                className="btn btn-outline-secondary btn-sm"
                                                                disabled
                                                                data-bs-toggle="tooltip"
                                                                data-bs-placement="top"
                                                                title="Fayl mavjud emas"
                                                            >
                                                                <i className="fa-solid fa-download"></i>
                                                            </button>
                                                        )}
                                                        {/* Dropbox URL tekshiruvi xavfsiz qilindi */}
                                                        {(presentation?.dropbox_url && typeof presentation.dropbox_url === 'string' && presentation.dropbox_url.trim() !== '') && (
                                                            <a
                                                                href={presentation.dropbox_url}
                                                                className="btn btn-outline-success btn-sm"
                                                                target="_blank"
                                                                rel="noopener noreferrer"
                                                                data-bs-toggle="tooltip"
                                                                data-bs-placement="top"
                                                                title="Dropbox"
                                                            >
                                                                <i className="fa-solid fa-cloud-arrow-down"></i>
                                                            </a>
                                                        )}
                                                        <a
                                                            href="#"
                                                            className="btn btn-sm btn-danger delete-presentation-btn"
                                                            data-bs-toggle="tooltip"
                                                            data-bs-placement="top"
                                                            title="O‘chirish"
                                                            onClick={() => handleDeletePresentation(presentation.id)}
                                                        >
                                                            <i className="fa-solid fa-trash"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    ))
                                ) : (
                                    <div className="col-12 text-center py-4">
                                        <p className="text-muted">📌 Siz hali taqdimot yaratmagansiz.</p>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Email tasdiqlash Modal */}
            <div
                className="modal fade verify-email-modal"
                id="verifyEmailModal"
                tabIndex="-1"
                aria-labelledby="verifyEmailModalLabel"
                aria-hidden="true"
            >
                <div className="modal-dialog modal-dialog-centered">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="verifyEmailModalLabel">
                                Emailni tasdiqlash
                            </h5>
                            <button
                                type="button"
                                className="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                            ></button>
                        </div>
                        <div className="modal-body">
                            <p>Emailingizga yuborilgan 6 xonali kodni kiriting:</p>
                            <form id="verifyCodeForm" onSubmit={handleVerifyCode}>
                                <div className="mb-3 text-center">
                                    <input
                                        type="text"
                                        className="form-control verify-code-input"
                                        name="code"
                                        id="verificationCode"
                                        maxLength="6"
                                        placeholder="123456"
                                        value={verificationCode}
                                        onChange={(e) => setVerificationCode(e.target.value.replace(/[^0-9]/g, ''))}
                                        required
                                    />
                                </div>
                                <button
                                    type="submit"
                                    className="btn btn-primary w-100"
                                    disabled={timer <= 0}
                                >
                                    Tasdiqlash
                                </button>
                            </form>
                            <p className="mt-3 text-center">
                                Kod kelmadi?{' '}
                                <a
                                    href="#"
                                    className="text-primary"
                                    id="resendCodeTrigger"
                                    onClick={handleResendCode}
                                >
                                    Qayta yuborish
                                </a>
                            </p>
                            <div id="timerDisplay" className="text-center text-muted mt-2">
                                {timer > 0
                                    ? `Qolgan vaqt: ${Math.floor(timer / 60)}:${(timer % 60)
                                          .toString()
                                          .padStart(2, '0')}`
                                    : 'Kodning muddati o‘tdi. Yangi kod so‘rang.'}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Feedback Modal */}
            <div
                className="modal fade feedback-modal"
                id="feedbackModal"
                tabIndex="-1"
                aria-labelledby="feedbackModalLabel"
                aria-hidden="true"
            >
                <div className="modal-dialog modal-dialog-centered">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="feedbackModalLabel">
                                Fikr qoldirasizmi?
                            </h5>
                            <button
                                type="button"
                                className="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                            ></button>
                        </div>
                        <div className="modal-body">
                            Siz {presentations.length} ta taqdimot yaratdingiz! Bizga fikr qoldirib, xizmatimizni
                            yaxshilashga yordam bera olasiz.
                        </div>
                        <div className="modal-footer">
                            <Link to="/feedback/feedback-view" className="btn btn-primary">
                                Ha
                            </Link>
                            <button
                                type="button"
                                className="btn btn-secondary"
                                data-bs-dismiss="modal"
                                onClick={setFeedbackLater}
                            >
                                Yo'q
                            </button>
                            <button
                                type="button"
                                className="btn btn-outline-secondary"
                                data-bs-dismiss="modal"
                                onClick={setFeedbackLater}
                            >
                                Keyinroq
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            {/* Sozlamalar Modal */}
            <div
                className="modal fade settings-modal"
                id="settingsModal"
                tabIndex="-1"
                aria-labelledby="settingsModalLabel"
                aria-hidden="true"
            >
                <div className="modal-dialog modal-dialog-centered">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="settingsModalLabel">
                                Sozlamalar
                            </h5>
                            <button
                                type="button"
                                className="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                            ></button>
                        </div>
                        <div className="modal-body">
                            <div className="mb-4">
                                <h6 className="mb-3">Bildirishnoma sozlamalari</h6>
                                <div className="form-check form-switch mb-2">
                                    <input
                                        className="form-check-input"
                                        type="checkbox"
                                        id="emailNotifications"
                                        checked={user.profile.email_notifications}
                                        onChange={(e) =>
                                            setUser({
                                                ...user,
                                                profile: {
                                                    ...user.profile,
                                                    email_notifications: e.target.checked,
                                                },
                                            })
                                        }
                                    />
                                    <label className="form-check-label" htmlFor="emailNotifications">
                                        Email bildirishnomalari
                                    </label>
                                </div>
                                <div className="form-check form-switch">
                                    <input
                                        className="form-check-input"
                                        type="checkbox"
                                        id="systemNotifications"
                                        checked={user.profile.system_notifications}
                                        onChange={(e) =>
                                            setUser({
                                                ...user,
                                                profile: {
                                                    ...user.profile,
                                                    system_notifications: e.target.checked,
                                                },
                                            })
                                        }
                                    />
                                    <label className="form-check-label" htmlFor="systemNotifications">
                                        Tizim ichidagi bildirishnomalar
                                    </label>
                                </div>
                            </div>
                            <div className="mb-4">
                                <h6 className="mb-3">Xavfsizlik</h6>
                                <Link to="/users/change-password" className="btn btn-outline-primary w-100">
                                    Parolni o‘zgartirish
                                </Link>
                            </div>
                            <div className="mb-4">
                                <h6 className="mb-3">Profilni o‘chirish</h6>
                                <button className="btn btn-danger w-100" onClick={deleteProfile}>
                                    Profilni o‘chirish
                                </button>
                            </div>
                        </div>
                        <div className="modal-footer">
                            <button
                                type="button"
                                className="btn btn-secondary"
                                data-bs-dismiss="modal"
                            >
                                Bekor qilish
                            </button>
                            <button type="button" className="btn btn-primary" onClick={saveSettings}>
                                Saqlash
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Profile;