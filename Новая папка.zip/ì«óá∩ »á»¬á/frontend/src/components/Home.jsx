import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import '../style/home.css';

function Home() {
    const [totalUsers, setTotalUsers] = useState(0);
    const [feedbacks, setFeedbacks] = useState([]);
    const [modalData, setModalData] = useState({
        id: '',
        message: '',
        username: '',
        date: ''
    });
    const [modalOpen, setModalOpen] = useState(false);

    // Total users va feedbacks'ni olish uchun API so'rov
    useEffect(() => {
        // Total users'ni olish
        axios.get('/api/users/total/')
            .then(response => {
                setTotalUsers(response.data.total_users);
            })
            .catch(error => {
                console.error('Total users olishda xatolik:', error);
            });

        // Feedbacks'ni olish
        axios.get('/api/feedbacks/')
            .then(response => {
                setFeedbacks(response.data);
            })
            .catch(error => {
                console.error('Feedbacks olishda xatolik:', error);
            });
    }, []);

    // Modalni ochish funksiyasi
    const openModal = (id, message, username, date) => {
        setModalData({ id, message, username, date });
        setModalOpen(true);
        const feedbackSlider = document.querySelector(".feedback-slider");
        if (feedbackSlider) {
            feedbackSlider.style.animationPlayState = "paused";
        }
    };

    // Modalni yopish funksiyasi
    const closeModal = () => {
        setModalOpen(false);
        const feedbackSlider = document.querySelector(".feedback-slider");
        if (feedbackSlider) {
            feedbackSlider.style.animationPlayState = "running";
        }
    };

    return (
        <div>
            {/* 🎯 Hero Section */}
            <div className="hero-section text-center text-white d-flex flex-column justify-content-center">
                <h1 className="display-2 fw-bold">AI Yordamida Taqdimotlar Yaratish Oson!</h1>
                <p className="lead fw-bold">Matn yozish va rasm izlashga vaqt sarflamang – AI barchasini o‘zi yaratadi!</p>
                <Link to="/presentations/create/" className="btn custom-btn btn-lg mt-3">
                    <i className="fa-solid fa-rocket me-2"></i>Taqdimot Yaratish
                </Link>
            </div>

            {/* 🏆 Bizning Afzalliklarimiz */}
            <div className="container text-center py-5">
                <h2 className="fw-bold mb-5">Nega aynan PresentlyAI?</h2>
                <div className="row mt-4">
                    <div className="col-md-4 mb-4">
                        <div className="feature-card fade-in-up">
                            <i className="fas fa-layer-group fa-3x mb-3"></i>
                            <h3>📌 150+ Shablon</h3>
                            <p>Turli dizayn va mavzulardagi tayyor shablonlar.</p>
                        </div>
                    </div>
                    <div className="col-md-4 mb-4">
                        <div className="feature-card fade-in-up">
                            <i className="fas fa-magic fa-3x mb-3"></i>
                            <h3>🤖 AI Matn & Rasm</h3>
                            <p>GPT va AI yordamida avtomatik tarkib yaratish.</p>
                        </div>
                    </div>
                    <div className="col-md-4 mb-4">
                        <div className="feature-card fade-in-up">
                            <i className="fas fa-cloud-upload-alt fa-3x mb-3"></i>
                            <h3>☁️ Dropbox Saqlash</h3>
                            <p>Yaratilgan taqdimotlaringizni xavfsiz saqlang.</p>
                        </div>
                    </div>
                </div>
            </div>

            {/* 📊 Statistika */}
            <div className="stats-section text-center py-5">
                <div className="container">
                    <h2 className="fw-bold mb-5">Bizning Statistikamiz</h2>
                    <div className="row mt-4">
                        <div className="col-md-4 mb-4">
                            <div className="stat-card fade-in-up">
                                <h2 className="display-4">{totalUsers}</h2>
                                <p>Foydalanuvchi</p>
                            </div>
                        </div>
                        <div className="col-md-4 mb-4">
                            <div className="stat-card fade-in-up">
                                <h2 className="display-4">10,000+</h2>
                                <p>Yaratilgan Taqdimotlar</p>
                            </div>
                        </div>
                        <div className="col-md-4 mb-4">
                            <div className="stat-card fade-in-up">
                                <h2 className="display-4">150+</h2>
                                <p>Shablonlar</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* ⭐ Foydalanuvchilar Fikri */}
            <div className="container py-5">
                <h2 className="fw-bold text-center mb-5">💬 Foydalanuvchilar Fikri</h2>
                <div className="feedback-slider-container">
                    <div className="feedback-slider">
                        {feedbacks.map(feedback => (
                            <div key={feedback.id} className="feedback-card">
                                <p className="feedback-date">{new Date(feedback.created_at).toLocaleString('uz-UZ', { year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric' })}</p>
                                <p className="feedback-text">{feedback.message.length > 60 ? feedback.message.substring(0, 60) + '...' : feedback.message}</p>
                                <p className="feedback-user">{feedback.user.username}</p>
                                <button
                                    className="feedback-btn"
                                    onClick={() => openModal(
                                        feedback.id,
                                        feedback.message,
                                        feedback.user.username,
                                        new Date(feedback.created_at).toLocaleString('uz-UZ', { year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric' })
                                    )}
                                >
                                    Batafsil
                                </button>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* 🔹 Modal Oyna */}
            <div id="feedbackModal" className={`modal ${modalOpen ? 'd-flex' : ''}`}>
                <div className="modal-content">
                    <span className="close" onClick={closeModal}>×</span>
                    <h4 className="modal-user">{modalData.username}</h4>
                    <p className="modal-date">{modalData.date}</p>
                    <p className="modal-text">{modalData.message}</p>
                </div>
            </div>
        </div>
    );
}

export default Home;