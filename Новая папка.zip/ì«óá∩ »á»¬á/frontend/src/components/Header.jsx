import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import axios from 'axios';

function Header() {
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const location = useLocation();

    // Foydalanuvchi autentifikatsiya holatini tekshirish
    useEffect(() => {
        axios.get('/api/users/check-auth/')
            .then(response => {
                setIsAuthenticated(response.data.is_authenticated);
            })
            .catch(error => {
                console.error('Autentifikatsiya holatini tekshirishda xatolik:', error);
                setIsAuthenticated(false);
            });
    }, []);

    return (
        <nav className="navbar navbar-expand-lg navbar-dark shadow-sm">
            <div className="container">
                <Link className="navbar-brand fw-bold" to="/">
                    <i className="fa-solid fa-chart-line me-2"></i>PresentlyAI
                </Link>
                <button
                    className="navbar-toggler"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarNav"
                    aria-controls="navbarNav"
                    aria-expanded="false"
                    aria-label="Toggle navigation"
                >
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarNav">
                    <ul className="navbar-nav me-auto">
                        <li className="nav-item">
                            <Link
                                className={`nav-link ${location.pathname === '/' ? 'active' : ''}`}
                                to="/"
                            >
                                <i className="fa-solid fa-house me-1"></i>Bosh Sahifa
                            </Link>
                        </li>
                    </ul>
                    <ul className="navbar-nav">
                        {isAuthenticated ? (
                            // Autentifikatsiya qilingan foydalanuvchilar uchun
                            <>
                                {/* Profil va Chiqish tugmalari keyinroq qo'shiladi */}
                            </>
                        ) : (
                            // Autentifikatsiya qilinmagan foydalanuvchilar uchun
                            <>
                                <li className="nav-item">
                                    <Link className="nav-link" to="/users/login/">
                                        <i className="fa-solid fa-sign-in-alt me-1"></i>Kirish
                                    </Link>
                                </li>
                                <li className="nav-item">
                                    <Link className="nav-link" to="/users/register/">
                                        <i className="fa-solid fa-user-plus me-1"></i>Ro‘yxatdan o‘tish
                                    </Link>
                                </li>
                            </>
                        )}
                    </ul>
                </div>
            </div>
        </nav>
    );
}

export default Header;