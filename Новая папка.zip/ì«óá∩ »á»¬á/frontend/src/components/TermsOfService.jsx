import React, { useEffect } from 'react';
import "../style/home.css"

const TermsOfService = () => {
    // Dark/Light tema sinxronizatsiyasi
    useEffect(() => {
        const currentTheme = localStorage.getItem('theme') || 'light';
        document.documentElement.setAttribute('data-theme', currentTheme);
    }, []);

    return (
        <div className="container mt-5">
            <h1 className="text-center">Foydalanish Shartlari</h1>
            <p className="text-muted text-center">Oxirgi yangilanish: 10-fevral, 2025</p>

            <hr />

            <h3>1. Xizmatdan foydalanish</h3>
            <p>Saytdan faqat qonuniy va odob-axloq qoidalariga mos holda foydalanish mumkin.</p>

            <h3>2. Ro‘yxatdan o‘tish</h3>
            <p>Saytda ro‘yxatdan o‘tish orqali siz kiritgan ma’lumotlaringiz haqiqat ekanini tasdiqlaysiz.</p>

            <h3>3. Taqdimotlar</h3>
            <p>Foydalanuvchilar yaratgan taqdimotlar ularga tegishli. Barcha yuklangan materiallar qonuniy bo‘lishi kerak.</p>

            <h3>4. Xizmatlarni o‘zgartirish</h3>
            <p>Biz har qanday vaqtda xizmatlarimizni o‘zgartirish yoki to‘xtatish huquqini saqlab qolamiz.</p>

            <h3>5. Xavfsizlik</h3>
            <p>Foydalanuvchilar hisoblari xavfsizligini ta’minlash uchun kuchli parollar ishlatishlari kerak.</p>

            <h3>6. Biz bilan bog‘lanish</h3>
            <p>
                Savollaringiz bo‘lsa, bizga{' '}
                <a href="mailto:support@presentlyai.com">support@presentlyai.com</a> orqali murojaat qiling.
            </p>
        </div>
    );
};

export default TermsOfService;