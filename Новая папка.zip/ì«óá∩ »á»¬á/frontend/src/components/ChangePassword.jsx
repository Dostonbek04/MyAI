import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import '../style/home.css'; // CSS faylini ulaymiz (agar uslublar shu yerda bo‘lsa)

const ChangePassword = () => {
    const [formData, setFormData] = useState({
        old_password: '',
        new_password1: '',
        new_password2: '',
    });
    const [errors, setErrors] = useState({});
    const [message, setMessage] = useState(null);
    const [messageType, setMessageType] = useState(''); // success yoki danger
    const navigate = useNavigate();

    // Forma maydonlarini yangilash
    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };

    // Forma yuborilganda
    const handleSubmit = async (e) => {
        e.preventDefault();
        setErrors({});
        setMessage(null);

        try {
            const response = await axios.post('/users/change-password/', formData, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRFToken': getCsrfToken(), // CSRF tokenni olish
                },
            });
            setMessage(response.data.message || 'Parol muvaffaqiyatli yangilandi!');
            setMessageType('success');
            setFormData({ old_password: '', new_password1: '', new_password2: '' });
            setTimeout(() => navigate('/presentations/list'), 2000); // 2 soniyadan so‘ng yo‘naltirish
        } catch (err) {
            if (err.response && err.response.data) {
                setErrors(err.response.data);
                setMessage(err.response.data.message || 'Parolni yangilashda xato yuz berdi.');
                setMessageType('danger');
            } else {
                setMessage('Server bilan bog‘lanishda xato yuz berdi.');
                setMessageType('danger');
            }
        }
    };

    // CSRF tokenni olish funksiyasi
    const getCsrfToken = () => {
        const name = 'csrftoken';
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    };

    // Dark/Light tema sinxronizatsiyasi
    useEffect(() => {
        const currentTheme = localStorage.getItem('theme') || 'light';
        document.documentElement.setAttribute('data-bs-theme', currentTheme);
    }, []);

    return (
        <div className="container mt-5">
            <div className="row justify-content-center">
                <div className="col-md-6 col-sm-10">
                    <div className="card shadow-lg border-0 rounded-lg">
                        {/* Card Header */}
                        <div className="card-header text-center bg-primary text-white">
                            <h3 className="mb-0">
                                <i className="fa-solid fa-lock me-2"></i>Parolni O‘zgartirish
                            </h3>
                        </div>

                        {/* Card Body */}
                        <div className="card-body p-4">
                            {/* Xabarlar */}
                            {message && (
                                <div className="alert-container mb-4">
                                    <div
                                        className={`alert alert-${messageType} alert-dismissible fade show`}
                                        role="alert"
                                    >
                                        {message}
                                        <button
                                            type="button"
                                            className="btn-close"
                                            data-bs-dismiss="alert"
                                            aria-label="Close"
                                            onClick={() => setMessage(null)}
                                        ></button>
                                    </div>
                                </div>
                            )}

                            {/* Forma */}
                            <form onSubmit={handleSubmit} id="changePasswordForm">
                                {/* Joriy Parol */}
                                <div className="mb-3">
                                    <label htmlFor="id_old_password" className="form-label fw-bold">
                                        <i className="fa-solid fa-key me-1"></i> Joriy Parol
                                    </label>
                                    <input
                                        type="password"
                                        name="old_password"
                                        id="id_old_password"
                                        className="form-control"
                                        value={formData.old_password}
                                        onChange={handleChange}
                                        required
                                    />
                                    {errors.old_password && (
                                        <div className="text-danger small mt-1">
                                            {errors.old_password.join(', ')}
                                        </div>
                                    )}
                                </div>

                                {/* Yangi Parol */}
                                <div className="mb-3">
                                    <label htmlFor="id_new_password1" className="form-label fw-bold">
                                        <i className="fa-solid fa-key me-1"></i> Yangi Parol
                                    </label>
                                    <input
                                        type="password"
                                        name="new_password1"
                                        id="id_new_password1"
                                        className="form-control"
                                        value={formData.new_password1}
                                        onChange={handleChange}
                                        required
                                    />
                                    {errors.new_password1 && (
                                        <div className="text-danger small mt-1">
                                            {errors.new_password1.join(', ')}
                                        </div>
                                    )}
                                </div>

                                {/* Yangi Parolni Tasdiqlash */}
                                <div className="mb-4">
                                    <label htmlFor="id_new_password2" className="form-label fw-bold">
                                        <i className="fa-solid fa-key me-1"></i> Yangi Parolni Tasdiqlash
                                    </label>
                                    <input
                                        type="password"
                                        name="new_password2"
                                        id="id_new_password2"
                                        className="form-control"
                                        value={formData.new_password2}
                                        onChange={handleChange}
                                        required
                                    />
                                    {errors.new_password2 && (
                                        <div className="text-danger small mt-1">
                                            {errors.new_password2.join(', ')}
                                        </div>
                                    )}
                                </div>

                                {/* Tugmalar */}
                                <button type="submit" className="btn btn-primary w-100 mb-3">
                                    <i className="fa-solid fa-sync-alt me-2"></i>Parolni Yangilash
                                </button>
                                <Link
                                    to="/presentations/list"
                                    className="btn btn-secondary w-100"
                                >
                                    <i className="fa-solid fa-arrow-left me-2"></i>Ortga
                                </Link>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ChangePassword;