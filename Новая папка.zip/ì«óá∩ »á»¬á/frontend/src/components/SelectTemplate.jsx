import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "../style/SelectTemplate.css"; // CSS faylini alohida saqlaymiz

const SelectTemplate = () => {
  const navigate = useNavigate();
  const [templates, setTemplates] = useState({ light: [], dark: [], professional: [] });
  const [selectedTemplateType, setSelectedTemplateType] = useState("light");
  const [selectedStyleIndex, setSelectedStyleIndex] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Sessiondan presentation_data va titles olish uchun
  const presentationData = JSON.parse(sessionStorage.getItem("presentation_data")) || {};
  const titles = JSON.parse(sessionStorage.getItem("titles")) || [];
  const listCount = presentationData.list_count || 8;

  // Backenddan shablonlarni olish
  useEffect(() => {
    const fetchTemplates = async () => {
      try {
        const response = await fetch("/api/templates/", {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`, // Agar autentifikatsiya tokeni kerak bo'lsa
          },
        });
        if (!response.ok) throw new Error("Shablonlarni yuklashda xato");
        const data = await response.json();
        setTemplates(data);
      } catch (err) {
        setError(err.message);
        console.error("Shablonlarni yuklashda xato:", err);
      }
    };
    fetchTemplates();
  }, []);

  // Preview rasmini yangilash
  const updatePreview = () => {
    const selectedTemplate = templates[selectedTemplateType]?.[selectedStyleIndex];
    return selectedTemplate?.image_path || "";
  };

  // Shablon dizaynlarini ro‘yxat sifatida ko‘rsatish
  const renderTemplateOptions = () => {
    if (!templates[selectedTemplateType]) return null;
    return templates[selectedTemplateType].map((template, index) => (
      <div
        key={index}
        className={`template-option fade-in-up ${index === selectedStyleIndex ? "selected" : ""}`}
        style={{ animationDelay: `${index * 0.1}s` }}
        onClick={() => {
          setSelectedStyleIndex(index);
          updatePreview();
        }}
      >
        <img
          src={template.image_path}
          alt={template.name}
          className="template-preview-img"
        />
        <span className="template-name">{template.name}</span>
      </div>
    ));
  };

  // Formani yuborish
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const formData = new FormData();
    formData.append("template_type", selectedTemplateType);
    formData.append("style_index", selectedStyleIndex);

    try {
      const response = await fetch("/presentations/select-template/", {
        method: "POST",
        body: formData,
        headers: {
          "X-CSRFToken": document.querySelector('meta[name="csrf-token"]')?.content || "",
        },
      });
      const data = await response.json();
      if (data.error) {
        setError(data.error);
        setLoading(false);
      } else {
        // Sessionni tozalash
        sessionStorage.removeItem("presentation_data");
        sessionStorage.removeItem("titles");
        navigate(data.redirect_url);
      }
    } catch (err) {
      setError("Taqdimot yaratishda xato yuz berdi.");
      setLoading(false);
      console.error("Xato:", err);
    }
  };

  return (
    <div className="container py-5">
      <div className="row justify-content-center">
        <div className="col-md-10">
          <div className="card shadow-lg border-0 rounded-lg">
            <div className="card-header text-center py-4">
              <h2 className="fw-bold">
                <i className="fa-solid fa-paint-roller me-2"></i>Shablon Tanlash - 2-qadam
              </h2>
            </div>
            <div className="card-body p-4">
              {error && (
                <div className="alert-container mb-4">
                  <div className="alert alert-danger alert-dismissible fade show" role="alert">
                    {error}
                    <button
                      type="button"
                      className="btn-close"
                      data-bs-dismiss="alert"
                      aria-label="Close"
                    ></button>
                  </div>
                </div>
              )}

              <form id="template-form" onSubmit={handleSubmit}>
                <input type="hidden" name="csrfmiddlewaretoken" value={document.querySelector('meta[name="csrf-token"]')?.content || ""} />

                <div className="row">
                  <div className="col-md-7 mb-4">
                    <h4 className="fw-bold mb-3">
                      <i className="fa-solid fa-eye me-2"></i>Shablon Preview
                    </h4>
                    <div id="preview-container" className="preview-box shadow-sm rounded">
                      <img
                        id="preview-image"
                        src={updatePreview()}
                        alt="Shablon Preview"
                        className="img-fluid"
                      />
                    </div>
                    <div className="mt-3 text-center">
                      <label className="form-label fw-bold">
                        <i className="fa-solid fa-list me-2"></i>Listlar soni
                      </label>
                      <p className="form-control-static">{listCount}</p>
                    </div>
                  </div>

                  <div className="col-md-5 mb-4">
                    <h4 className="fw-bold mb-3">
                      <i className="fa-solid fa-palette me-2"></i>Shablon Tanlash
                    </h4>
                    <div className="template-type-buttons mb-3">
                      {["light", "dark", "professional"].map((type) => (
                        <button
                          key={type}
                          type="button"
                          className={`btn template-type-btn ${selectedTemplateType === type ? "active" : ""}`}
                          onClick={() => {
                            setSelectedTemplateType(type);
                            setSelectedStyleIndex(0);
                          }}
                        >
                          {type.charAt(0).toUpperCase() + type.slice(1)}
                        </button>
                      ))}
                    </div>

                    <div id="template-options" className="template-options-container">
                      {renderTemplateOptions()}
                    </div>
                  </div>
                </div>

                <input type="hidden" name="template_type" value={selectedTemplateType} />
                <input type="hidden" name="style_index" value={selectedStyleIndex} />

                <div className="text-center" id="submit-button-container">
                  <button
                    type="submit"
                    className="btn btn-lg custom-btn"
                    id="create-presentation-btn"
                    disabled={loading}
                  >
                    {loading ? (
                      <span className="loading-spinner">
                        <span className="spinner-border spinner-border-sm pulse" role="status" aria-hidden="true"></span>
                        Yuklanmoqda...
                      </span>
                    ) : (
                      <span className="button-text">
                        <i className="fa-solid fa-check me-2"></i>Taqdimotni Yaratish
                      </span>
                    )}
                  </button>
                </div>
              </form>

              <div id="loading-overlay" className={`loading-overlay ${loading ? "" : "d-none"}`}>
                <div className="loading-content">
                  <div className="css-spinner"></div>
                  <p className="loading-text">Yaratilmoqda...</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SelectTemplate;