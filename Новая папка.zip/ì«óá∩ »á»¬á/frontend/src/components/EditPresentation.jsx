import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import "../style/EditPresentation.css";

const EditPresentation = () => {
  const { presentation_id } = useParams();
  const navigate = useNavigate();
  const [slides, setSlides] = useState([]);
  const [history, setHistory] = useState([]); // Undo uchun tarix
  const [redoStack, setRedoStack] = useState([]); // Redo uchun stack
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [title, setTitle] = useState("");

  // Backenddan taqdimot ma'lumotlarini olish
  useEffect(() => {
    const fetchPresentation = async () => {
      try {
        const response = await fetch(`/api/presentations/${presentation_id}/`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        });
        if (!response.ok) throw new Error("Taqdimotni yuklashda xato");
        const data = await response.json();
        setSlides(data.slides_data || []);
        setTitle(data.title || "Untitled Presentation");
        // localStorage'ga saqlash
        localStorage.setItem(`presentation_${presentation_id}`, JSON.stringify(data.slides_data));
        setHistory([data.slides_data]); // Dastlabki holatni tarixga qo'shish
        setLoading(false);
      } catch (err) {
        setError(err.message);
        setLoading(false);
      }
    };
    fetchPresentation();

    // Sahifa yopilganda localStorage'ni tozalash
    const handleBeforeUnload = () => {
      localStorage.removeItem(`presentation_${presentation_id}`);
    };
    window.addEventListener("beforeunload", handleBeforeUnload);

    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
      localStorage.removeItem(`presentation_${presentation_id}`);
    };
  }, [presentation_id]);

  // Drag-and-Drop funksiyasi
  const onDragEnd = (result) => {
    if (!result.destination) return;

    const newSlides = [...slides];
    const [reorderedItem] = newSlides.splice(result.source.index, 1);
    newSlides.splice(result.destination.index, 0, reorderedItem);

    // Tarixni yangilash
    setHistory([...history, slides]);
    setRedoStack([]); // Redo stack'ni tozalash
    setSlides(newSlides);
    localStorage.setItem(`presentation_${presentation_id}`, JSON.stringify(newSlides));
  };

  // Slayd matnini tahrirlash
  const handleSlideChange = (index, field, value) => {
    const newSlides = [...slides];
    newSlides[index] = { ...newSlides[index], [field]: value };
    setHistory([...history, slides]);
    setRedoStack([]);
    setSlides(newSlides);
    localStorage.setItem(`presentation_${presentation_id}`, JSON.stringify(newSlides));
  };

  // Undo funksiyasi
  const handleUndo = () => {
    if (history.length <= 1) return;
    const newHistory = [...history];
    const previousState = newHistory.pop();
    setRedoStack([...redoStack, slides]);
    setSlides(previousState);
    setHistory(newHistory);
    localStorage.setItem(`presentation_${presentation_id}`, JSON.stringify(previousState));
  };

  // Redo funksiyasi
  const handleRedo = () => {
    if (redoStack.length === 0) return;
    const newRedoStack = [...redoStack];
    const nextState = newRedoStack.pop();
    setHistory([...history, slides]);
    setSlides(nextState);
    setRedoStack(newRedoStack);
    localStorage.setItem(`presentation_${presentation_id}`, JSON.stringify(nextState));
  };

  // Saqlash funksiyasi
  const handleSave = async () => {
    try {
      const response = await fetch(`/api/presentations/${presentation_id}/update/`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("token")}`,
          "X-CSRFToken": document.querySelector('meta[name="csrf-token"]')?.content || "",
        },
        body: JSON.stringify({ title, slides_data: slides }),
      });
      if (!response.ok) throw new Error("Saqlashda xato");
      const data = await response.json();
      alert("✅ Taqdimot muvaffaqiyatli saqlandi!");
      navigate("/users/profile");
    } catch (err) {
      setError(err.message);
    }
  };

  if (loading) return <div className="loading-overlay"><div className="css-spinner"></div><p>Yuklanmoqda...</p></div>;
  if (error) return <div className="alert alert-danger">{error}</div>;

  return (
    <div className="container py-5">
      <div className="row justify-content-center">
        <div className="col-md-10">
          <div className="card shadow-lg border-0 rounded-lg">
            <div className="card-header text-center py-4">
              <h2 className="fw-bold">
                <i className="fa-solid fa-edit me-2"></i>Taqdimotni Tahrirlash
              </h2>
            </div>
            <div className="card-body p-4">
              <div className="mb-4">
                <label className="form-label fw-bold">
                  <i className="fa-solid fa-heading me-2"></i>Sarlavha
                </label>
                <input
                  type="text"
                  className="form-control"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                />
              </div>

              <div className="d-flex justify-content-between mb-4">
                <button
                  className="btn btn-secondary"
                  onClick={handleUndo}
                  disabled={history.length <= 1}
                >
                  <i className="fa-solid fa-undo me-2"></i>Undo
                </button>
                <button
                  className="btn btn-secondary"
                  onClick={handleRedo}
                  disabled={redoStack.length === 0}
                >
                  <i className="fa-solid fa-redo me-2"></i>Redo
                </button>
              </div>

              <DragDropContext onDragEnd={onDragEnd}>
                <Droppable droppableId="slides">
                  {(provided) => (
                    <div {...provided.droppableProps} ref={provided.innerRef}>
                      {slides.map((slide, index) => (
                        <Draggable key={slide.id} draggableId={String(slide.id)} index={index}>
                          {(provided) => (
                            <div
                              ref={provided.innerRef}
                              {...provided.draggableProps}
                              {...provided.dragHandleProps}
                              className="slide-card mb-3 p-3 shadow-sm rounded"
                            >
                              <h5>Slayd {index + 1}</h5>
                              <div className="mb-2">
                                <label className="form-label">Sarlavha</label>
                                <input
                                  type="text"
                                  className="form-control"
                                  value={slide.title || ""}
                                  onChange={(e) => handleSlideChange(index, "title", e.target.value)}
                                />
                              </div>
                              <div className="mb-2">
                                <label className="form-label">Matn</label>
                                <textarea
                                  className="form-control"
                                  value={slide.content || ""}
                                  onChange={(e) => handleSlideChange(index, "content", e.target.value)}
                                  rows="3"
                                />
                              </div>
                              {slide.image && (
                                <div className="mb-2">
                                  <label className="form-label">Rasm</label>
                                  <img src={slide.image} alt={`Slide ${index + 1}`} className="img-fluid" style={{ maxWidth: "100px" }} />
                                </div>
                              )}
                            </div>
                          )}
                        </Draggable>
                      ))}
                      {provided.placeholder}
                    </div>
                  )}
                </Droppable>
              </DragDropContext>

              <div className="text-center mt-4">
                <button className="btn btn-lg custom-btn" onClick={handleSave}>
                  <i className="fa-solid fa-save me-2"></i>Saqlash
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditPresentation;