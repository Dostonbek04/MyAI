import React from 'react';

const PrivacyPolicy = () => {
    return (
        <div className="container mt-5">
            <h1 className="text-center">Maxfiylik Siyosati</h1>
            <p className="text-muted text-center">Oxirgi yangilanish: 10-fevral, 2025</p>

            <hr />

            <h3>1. Ma'lumotlarni to‘plash</h3>
            <p>Biz foydalanuvchilar haqida quyidagi ma’lumotlarni yig‘amiz:</p>
            <ul>
                <li>Ism va email manzili (ro‘yxatdan o‘tishda)</li>
                <li>Taqdimot yaratish faoliyati</li>
                <li>Saytdan foydalanish statistikasi</li>
            </ul>

            <h3>2. Ma’lumotlaringiz qanday ishlatiladi?</h3>
            <p>Biz foydalanuvchilar ma’lumotlarini quyidagi maqsadlarda ishlatamiz:</p>
            <ul>
                <li>Xizmatlarni taqdim etish va yaxshilash</li>
                <li>Foydalanuvchi qo‘llab-quvvatlashini ta’minlash</li>
                <li>Xavfsizlik va spam oldini olish</li>
            </ul>

            <h3>3. Uchinchi tomon xizmatlari</h3>
            <p>Biz ma’lumotlaringizni uchinchi tomonlarga bermaymiz. Lekin quyidagi xizmatlardan foydalanamiz:</p>
            <ul>
                <li>Google Analytics – sayt statistikasi</li>
                <li>Dropbox – taqdimotlarni saqlash</li>
            </ul>

            <h3>4. Foydalanuvchi huquqlari</h3>
            <p>Foydalanuvchilar istalgan vaqtda o‘z ma’lumotlarini o‘zgartirish yoki o‘chirish huquqiga ega.</p>

            <h3>5. Biz bilan bog‘lanish</h3>
            <p>
                Agar sizda savollar bo‘lsa, bizga{' '}
                <a href="mailto:support@presentlyai.com">support@presentlyai.com</a>{' '}
                manziliga yozishingiz mumkin.
            </p>
        </div>
    );
};

export default PrivacyPolicy;