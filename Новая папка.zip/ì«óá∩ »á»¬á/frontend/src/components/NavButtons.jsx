import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import axios from 'axios';

function NavButtons() {
    const location = useLocation();
    const [isAuthenticated, setIsAuthenticated] = useState(false);

    useEffect(() => {
        axios.get('/api/users/check-auth/')
            .then(response => {
                setIsAuthenticated(response.data.is_authenticated);
            })
            .catch(error => {
                console.error('Autentifikatsiya holatini tekshirishda xatolik:', error);
                setIsAuthenticated(false);
            });
    }, []);

    if (!isAuthenticated) return null;

    return (
        <div className="nav-buttons-container position-fixed start-0 p-3">
            {/* Orqaga tugmasi faqat create_presentation va select_template sahifalarida ko‘rinadi */}
            {(location.pathname === '/presentations/create/' || location.pathname === '/presentations/select-template/') && (
                <Link
                    to={location.pathname === '/presentations/select-template/' ? '/presentations/generate-titles/' : '/users/profile/'}
                    className="btn btn-sm btn-nav"
                >
                    <i className="bi bi-arrow-left"></i> Orqaga
                </Link>
            )}
            {/* Bosh Sahifa tugmasi faqat profil sahifasida ko‘rinmaydi */}
            {location.pathname !== '/users/profile/' && (
                <Link to="/users/profile/" className="btn btn-sm btn-nav">
                    <i className="fa-solid fa-house"></i> Bosh Sahifa
                </Link>
            )}
        </div>
    );
}

export default NavButtons;