import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../style/Register.css';

const Register = () => {
    const [formData, setFormData] = useState({
        username: '',
        email: '',
        password1: '',
        password2: '',
    });
    const [errors, setErrors] = useState({});
    const [messages, setMessages] = useState([]);
    const [passwordValid, setPasswordValid] = useState({
        length: false,
        uppercase: false,
        number: false,
    });
    const [isSubmitEnabled, setIsSubmitEnabled] = useState(false);
    const navigate = useNavigate();

    // Dark/Light tema sinxronizatsiyasi
    useEffect(() => {
        const currentTheme = localStorage.getItem('theme') || 'light';
        document.documentElement.setAttribute('data-theme', currentTheme);
    }, []);

    // Forma o‘zgarishlarini boshqarish
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });

        if (name === 'password1') {
            validatePassword(value);
        }
    };

    // Parolni tekshirish
    const validatePassword = (password) => {
        const length = password.length >= 8;
        const uppercase = /[A-Z]/.test(password);
        const number = /[0-9]/.test(password);

        setPasswordValid({ length, uppercase, number });
        setIsSubmitEnabled(length && uppercase && number);
    };

    // CSRF tokenni olish
    const getCsrfToken = () => {
        const name = 'csrftoken';
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    };

    // Formani yuborish
    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('/users/register/', formData, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRFToken': getCsrfToken(),
                },
            });
            setMessages([{ tags: 'success', message: response.data.message || 'Ro‘yxatdan o‘tish muvaffaqiyatli!' }]);
            setErrors({});
            setTimeout(() => navigate('/users/login'), 2000);
        } catch (err) {
            if (err.response && err.response.data) {
                setErrors(err.response.data);
                setMessages([{ tags: 'error', message: 'Ro‘yxatdan o‘tishda xato yuz berdi!' }]);
            } else {
                setMessages([{ tags: 'error', message: 'Server bilan bog‘lanishda xato yuz berdi!' }]);
            }
        }
    };

    return (
        <div className="container d-flex justify-content-center align-items-center min-vh-80">
            <div className="col-md-6">
                <div className="card shadow-lg rounded-lg fade-in">
                    <div className="card-header text-center py-4">
                        <h2 className="fw-bold">
                            <i className="fa-solid fa-user-plus me-2"></i>Ro‘yxatdan o‘tish
                        </h2>
                    </div>
                    <div className="card-body p-4">
                        {/* Xatolik yoki muvaffaqiyat xabarlari */}
                        {messages.map((msg, index) => (
                            <div
                                key={index}
                                className={`alert ${
                                    msg.tags === 'success' ? 'alert-success' : 'alert-danger'
                                } alert-dismissible fade show`}
                                role="alert"
                            >
                                <i
                                    className={`fa-solid ${
                                        msg.tags === 'success'
                                            ? 'fa-check-circle'
                                            : 'fa-exclamation-triangle'
                                    } me-2`}
                                ></i>
                                {msg.message}
                                <button
                                    type="button"
                                    className="btn-close"
                                    data-bs-dismiss="alert"
                                    aria-label="Close"
                                ></button>
                            </div>
                        ))}

                        <form onSubmit={handleSubmit} className="mt-3">
                            {/* Foydalanuvchi nomi */}
                            <div className="mb-4">
                                <label htmlFor="username" className="form-label fw-bold">
                                    <i className="fa-solid fa-user me-2"></i>Foydalanuvchi nomi
                                </label>
                                <small className="form-text d-block mb-1">
                                    Bu yerda foydalanuvchi nomingizni kiriting (masalan, "user123")
                                </small>
                                <div className="input-group">
                                    <span className="input-group-text">
                                        <i className="fa-solid fa-user"></i>
                                    </span>
                                    <input
                                        type="text"
                                        name="username"
                                        id="username"
                                        className="form-control"
                                        value={formData.username}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                                {errors.username && (
                                    <div className="text-danger mt-1">
                                        {errors.username.map((error, index) => (
                                            <small key={index}>{error}</small>
                                        ))}
                                    </div>
                                )}
                            </div>

                            {/* Email */}
                            <div className="mb-4">
                                <label htmlFor="email" className="form-label fw-bold">
                                    <i className="fa-solid fa-envelope me-2"></i>Email
                                </label>
                                <small className="form-text d-block mb-1">
                                    Email manzilingizni kiriting (masalan, "example@gmail.com")
                                </small>
                                <div className="input-group">
                                    <span className="input-group-text">
                                        <i className="fa-solid fa-envelope"></i>
                                    </span>
                                    <input
                                        type="email"
                                        name="email"
                                        id="email"
                                        className="form-control"
                                        value={formData.email}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                                {errors.email && (
                                    <div className="text-danger mt-1">
                                        {errors.email.map((error, index) => (
                                            <small key={index}>{error}</small>
                                        ))}
                                    </div>
                                )}
                            </div>

                            {/* Parol */}
                            <div className="mb-4">
                                <label htmlFor="password1" className="form-label fw-bold">
                                    <i className="fa-solid fa-lock me-2"></i>Parol
                                </label>
                                <small className="form-text d-block mb-1">
                                    Parolingizni kiriting (quyidagi talablarga rioya qiling)
                                </small>
                                <div className="input-group">
                                    <span className="input-group-text">
                                        <i className="fa-solid fa-lock"></i>
                                    </span>
                                    <input
                                        type="password"
                                        name="password1"
                                        id="password1"
                                        className="form-control"
                                        value={formData.password1}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                                {errors.password1 && (
                                    <div className="text-danger mt-1">
                                        {errors.password1.map((error, index) => (
                                            <small key={index}>{error}</small>
                                        ))}
                                    </div>
                                )}
                            </div>

                            {/* Parol talablari */}
                            <div className="mb-4 password-requirements">
                                <p className="mb-2">
                                    <strong>🔹 Parol talablari:</strong>
                                </p>
                                <ul className="list-unstyled">
                                    <li
                                        id="length"
                                        className={`d-flex align-items-center mb-2 ${
                                            passwordValid.length ? 'text-success' : 'text-danger'
                                        }`}
                                    >
                                        <span className="status-icon me-2">
                                            {passwordValid.length ? '✅' : '❌'}
                                        </span>
                                        Kamida 8 ta belgi
                                    </li>
                                    <li
                                        id="uppercase"
                                        className={`d-flex align-items-center mb-2 ${
                                            passwordValid.uppercase ? 'text-success' : 'text-danger'
                                        }`}
                                    >
                                        <span className="status-icon me-2">
                                            {passwordValid.uppercase ? '✅' : '❌'}
                                        </span>
                                        Kamida 1 ta katta harf (A-Z)
                                    </li>
                                    <li
                                        id="number"
                                        className={`d-flex align-items-center mb-2 ${
                                            passwordValid.number ? 'text-success' : 'text-danger'
                                        }`}
                                    >
                                        <span className="status-icon me-2">
                                            {passwordValid.number ? '✅' : '❌'}
                                        </span>
                                        Kamida 1 ta raqam (0-9)
                                    </li>
                                </ul>
                            </div>

                            {/* Parol tasdiqlash */}
                            <div className="mb-4">
                                <label htmlFor="password2" className="form-label fw-bold">
                                    <i className="fa-solid fa-lock me-2"></i>Parolni tasdiqlang
                                </label>
                                <small className="form-text d-block mb-1">
                                    Yuqoridagi parolni qayta kiriting
                                </small>
                                <div className="input-group">
                                    <span className="input-group-text">
                                        <i className="fa-solid fa-lock"></i>
                                    </span>
                                    <input
                                        type="password"
                                        name="password2"
                                        id="password2"
                                        className="form-control"
                                        value={formData.password2}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                                {errors.password2 && (
                                    <div className="text-danger mt-1">
                                        {errors.password2.map((error, index) => (
                                            <small key={index}>{error}</small>
                                        ))}
                                    </div>
                                )}
                            </div>

                            <button
                                type="submit"
                                className="btn btn-primary w-100 custom-btn"
                                id="submit-btn"
                                disabled={!isSubmitEnabled}
                            >
                                <i className="fa-solid fa-user-plus me-2"></i>Ro‘yxatdan o‘tish
                            </button>
                        </form>

                        <p className="text-center mt-4">
                            Allaqachon hisobingiz bormi?{' '}
                            <Link to="/users/login" className="register-link">
                                Kirish
                            </Link>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Register;