import React, { useState, useEffect } from 'react';
import axios from 'axios';

function SystemMessages() {
    const [messages, setMessages] = useState([]);
    const [showModal, setShowModal] = useState(false);

    useEffect(() => {
        // Tizim xabarlarini olish
        axios.get('/api/system-messages/')
            .then(response => {
                if (response.data.messages && response.data.messages.length > 0) {
                    setMessages(response.data.messages);
                    setShowModal(true);

                    // Xabar uzunligini hisoblash va vaqtni aniqlash
                    let totalWords = 0;
                    response.data.messages.forEach(message => {
                        const words = message.message.trim().split(/\s+/).length;
                        totalWords += words;
                    });

                    // Har 10 so‘z uchun 15 soniya (minimum 5 soniya)
                    const duration = Math.max(5, Math.ceil(totalWords / 10) * 15) * 1000;

                    setTimeout(() => {
                        const modalDialog = document.querySelector('#systemMessagesModal .modal-dialog');
                        if (modalDialog) {
                            modalDialog.style.animation = 'slideUp 0.5s ease-out forwards';
                            setTimeout(() => {
                                setShowModal(false);
                            }, 500);
                        }
                    }, duration);
                }
            })
            .catch(error => {
                console.error('Tizim xabarlarini olishda xatolik:', error);
            });
    }, []);

    if (!showModal) return null;

    return (
        <div className="modal top-message-modal" id="systemMessagesModal" tabIndex="-1" aria-hidden="true">
            <div className="modal-dialog">
                <div className="modal-content">
                    <div className="modal-body">
                        {messages.map((message, index) => (
                            <div key={index} className={`alert alert-${message.tags} mb-2`} role="alert">
                                {message.message}
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
}

export default SystemMessages;