import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../style/FeedbackForm.css';

const FeedbackForm = () => {
    const [user, setUser] = useState({ username: '', email: '' });
    const [message, setMessage] = useState('');
    const [charCount, setCharCount] = useState(0);
    const [isSubmitEnabled, setIsSubmitEnabled] = useState(false);
    const [responseMessage, setResponseMessage] = useState('');
    const [errors, setErrors] = useState({});
    const navigate = useNavigate();

    // Foydalanuvchi ma'lumotlarini olish va tema sinxronizatsiyasi
    useEffect(() => {
        const fetchUserData = async () => {
            try {
                const response = await axios.get('/users/profile/', {
                    headers: { 'X-Requested-With': 'XMLHttpRequest' },
                });
                setUser(response.data.user);
            } catch (err) {
                console.error('Foydalanuvchi ma\'lumotlarini olishda xato:', err);
            }
        };

        fetchUserData();

        // Dark/Light tema sinxronizatsiyasi
        const currentTheme = localStorage.getItem('theme') || 'light';
        document.documentElement.setAttribute('data-theme', currentTheme);
    }, []);

    // Belgilarni hisoblash va tugmani boshqarish
    const handleMessageChange = (e) => {
        const value = e.target.value;
        const maxLength = 150;

        if (value.length <= maxLength) {
            setMessage(value);
            setCharCount(value.length);
            setIsSubmitEnabled(value.length > 0);
        }
    };

    // CSRF tokenni olish
    const getCsrfToken = () => {
        const name = 'csrftoken';
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    };

    // Formani yuborish
    const handleSubmit = async (e) => {
        e.preventDefault();
        setErrors({});
        setResponseMessage('');

        try {
            const response = await axios.post(
                '/feedback/submit/',
                { message },
                {
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRFToken': getCsrfToken(),
                    },
                }
            );
            setResponseMessage('✅ Fikringiz muvaffaqiyatli jo‘natildi!');
            setMessage('');
            setCharCount(0);
            setIsSubmitEnabled(false);
            setTimeout(() => navigate('/users/profile'), 2000); // Profilga qaytish
        } catch (err) {
            if (err.response && err.response.data && err.response.data.errors) {
                const parsedErrors = JSON.parse(err.response.data.errors);
                setErrors(parsedErrors);
                setResponseMessage('❌ Xatolik yuz berdi. Iltimos, qayta urinib ko‘ring.');
            } else {
                setResponseMessage('❌ Xatolik yuz berdi. Iltimos, qayta urinib ko‘ring.');
            }
        }
    };

    return (
        <div className="container py-5">
            <div className="row justify-content-center">
                <div className="col-md-8">
                    <div className="card shadow-lg border-0 rounded-lg">
                        <div className="card-header text-center py-4">
                            <h2 className="fw-bold">
                                <i className="fa-solid fa-comment-dots me-2"></i> Fikr Qoldiring
                            </h2>
                        </div>
                        <div className="card-body p-4">
                            {responseMessage && (
                                <div
                                    className={`alert ${
                                        responseMessage.includes('muvaffaqiyatli')
                                            ? 'alert-success'
                                            : 'alert-danger'
                                    } alert-dismissible fade show`}
                                    role="alert"
                                >
                                    {responseMessage}
                                    <button
                                        type="button"
                                        className="btn-close"
                                        data-bs-dismiss="alert"
                                        aria-label="Close"
                                    ></button>
                                </div>
                            )}

                            <form onSubmit={handleSubmit} className="feedback-form">
                                {/* Foydalanuvchi ma'lumotlari */}
                                <div className="user-info text-center mb-4">
                                    <p>
                                        <i className="fa-solid fa-user me-2"></i>
                                        <strong>Foydalanuvchi:</strong> {user.username || 'Noma\'lum'}
                                    </p>
                                    <p>
                                        <i className="fa-solid fa-envelope me-2"></i>
                                        <strong>Email:</strong> {user.email || 'Noma\'lum'}
                                    </p>
                                </div>

                                {/* Fikr maydoni */}
                                <div className="mb-4">
                                    <label htmlFor="message" className="form-label fw-bold">
                                        <i className="fa-solid fa-comment me-2"></i>Fikringiz:
                                    </label>
                                    <textarea
                                        id="message"
                                        name="message"
                                        className="form-control"
                                        rows="4"
                                        maxLength="150"
                                        value={message}
                                        onChange={handleMessageChange}
                                        required
                                    ></textarea>
                                    {errors.message && (
                                        <p className="text-danger mt-1">{errors.message.message}</p>
                                    )}

                                    {/* Belgilar soni hisoblagich */}
                                    <small
                                        id="char-count"
                                        className={`char-count d-block mt-2 ${
                                            charCount === 150 ? 'text-danger' : 'text-muted'
                                        }`}
                                    >
                                        {charCount} / 150
                                    </small>
                                </div>

                                {/* Jo‘natish tugmasi */}
                                <button
                                    type="submit"
                                    className="btn custom-btn w-100"
                                    id="submit-btn"
                                    disabled={!isSubmitEnabled}
                                >
                                    <i className="fa-solid fa-paper-plane me-2"></i>Jo‘natish
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default FeedbackForm;