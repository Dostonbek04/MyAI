import React from 'react';
import { Link } from 'react-router-dom';

function Footer() {
    return (
        <footer className="text-white text-center py-4 mt-5">
            <div className="container">
                <p className="mb-2">© 2025 PresentlyAI. Barcha huquqlar himoyalangan.</p>
                <small>
                    <Link to="/privacy-policy/" className="text-white">Maxfiylik siyosati</Link> |{' '}
                    <Link to="/terms/" className="text-white">Foydalanish shartlari</Link>
                </small>
            </div>
        </footer>
    );
}

export default Footer;