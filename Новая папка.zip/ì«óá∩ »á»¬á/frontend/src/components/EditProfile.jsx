import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import '../style/EditProfile.css'; // CSS faylini ulaymiz

const EditProfile = () => {
    const [formData, setFormData] = useState({
        username: '',
        email: '',
        image: null,
    });
    const [errors, setErrors] = useState({});
    const [message, setMessage] = useState(null);
    const [messageType, setMessageType] = useState(''); // success yoki danger
    const navigate = useNavigate();

    // Dastlabki ma'lumotlarni olish
    useEffect(() => {
        const fetchProfileData = async () => {
            try {
                const response = await axios.get('/users/edit-profile/', {
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                    },
                });
                setFormData({
                    username: response.data.username || '',
                    email: response.data.email || '',
                    image: null,
                });
            } catch (err) {
                setMessage('Profilingizni yuklashda xato yuz berdi.');
                setMessageType('danger');
            }
        };
        fetchProfileData();

        // Dark/Light tema sinxronizatsiyasi
        const currentTheme = localStorage.getItem('theme') || 'light';
        document.documentElement.setAttribute('data-theme', currentTheme);
    }, []);

    // Forma maydonlarini yangilash
    const handleChange = (e) => {
        const { name, value, files } = e.target;
        setFormData({
            ...formData,
            [name]: files ? files[0] : value,
        });
    };

    // Forma yuborilganda
    const handleSubmit = async (e) => {
        e.preventDefault();
        setErrors({});
        setMessage(null);

        const formDataToSend = new FormData();
        formDataToSend.append('username', formData.username);
        formDataToSend.append('email', formData.email);
        if (formData.image) {
            formDataToSend.append('image', formData.image);
        }

        try {
            const response = await axios.post('/users/edit-profile/', formDataToSend, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRFToken': getCsrfToken(),
                    'Content-Type': 'multipart/form-data',
                },
            });
            setMessage(response.data.message || 'Profil muvaffaqiyatli yangilandi!');
            setMessageType('success');
            setTimeout(() => navigate('/users/profile'), 2000); // 2 soniyadan so‘ng yo‘naltirish
        } catch (err) {
            if (err.response && err.response.data) {
                setErrors(err.response.data);
                setMessage(err.response.data.message || 'Profilni yangilashda xato yuz berdi.');
                setMessageType('danger');
            } else {
                setMessage('Server bilan bog‘lanishda xato yuz berdi.');
                setMessageType('danger');
            }
        }
    };

    // CSRF tokenni olish funksiyasi
    const getCsrfToken = () => {
        const name = 'csrftoken';
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    };

    return (
        <div className="container d-flex justify-content-center align-items-center">
            <div className="row justify-content-center w-100">
                <div className="col-md-6">
                    <div className="card mt-5 shadow-lg border-0 rounded-lg">
                        <div className="card-header text-center">
                            <h3 className="fw-bold">
                                <i className="fa-solid fa-user-pen me-2"></i> Profilni Tahrirlash
                            </h3>
                            <p className="text-muted mt-2">
                                Bu yerda profilingiz ma'lumotlarini o‘zgartirishingiz mumkin. Ismingizni, elektron pochtangizni yoki profil rasmingizni yangilang.
                            </p>
                        </div>
                        <div className="card-body">
                            {/* Xabarlar */}
                            {message && (
                                <div className="alert-container mb-4">
                                    <div
                                        className={`alert alert-${messageType} alert-dismissible fade show`}
                                        role="alert"
                                    >
                                        {message}
                                        <button
                                            type="button"
                                            className="btn-close"
                                            data-bs-dismiss="alert"
                                            aria-label="Close"
                                            onClick={() => setMessage(null)}
                                        ></button>
                                    </div>
                                </div>
                            )}

                            {/* Forma */}
                            <form onSubmit={handleSubmit} encType="multipart/form-data">
                                {/* Username */}
                                <div className="form-group mb-4">
                                    <div className="mb-3">
                                        <label htmlFor="id_username" className="form-label fw-bold">
                                            <i className="fa-solid fa-user me-1"></i> Foydalanuvchi nomi
                                        </label>
                                        <small className="text-muted d-block mb-2">
                                            Ismingizni kiriting (masalan, @john_doe)
                                        </small>
                                        <input
                                            type="text"
                                            name="username"
                                            id="id_username"
                                            className="form-control custom-input"
                                            value={formData.username}
                                            onChange={handleChange}
                                            required
                                        />
                                        {errors.username && (
                                            <div className="text-danger mt-1">
                                                {errors.username.map((error, index) => (
                                                    <small key={index}>{error}</small>
                                                ))}
                                            </div>
                                        )}
                                    </div>

                                    {/* Email */}
                                    <div className="mb-3">
                                        <label htmlFor="id_email" className="form-label fw-bold">
                                            <i className="fa-solid fa-envelope me-1"></i> Elektron pochta
                                        </label>
                                        <small className="text-muted d-block mb-2">
                                            Elektron pochtangizni kiriting (masalan, example@gmail.com)
                                        </small>
                                        <input
                                            type="email"
                                            name="email"
                                            id="id_email"
                                            className="form-control custom-input"
                                            value={formData.email}
                                            onChange={handleChange}
                                            required
                                        />
                                        {errors.email && (
                                            <div className="text-danger mt-1">
                                                {errors.email.map((error, index) => (
                                                    <small key={index}>{error}</small>
                                                ))}
                                            </div>
                                        )}
                                    </div>

                                    {/* Image */}
                                    <div className="mb-3">
                                        <label htmlFor="id_image" className="form-label fw-bold">
                                            <i className="fa-solid fa-camera me-1"></i> Profil rasmi
                                        </label>
                                        <small className="text-muted d-block mb-2">
                                            Rasmni yuklang (PNG, JPG formatida, maks. 5MB)
                                        </small>
                                        <input
                                            type="file"
                                            name="image"
                                            id="id_image"
                                            className="form-control custom-input"
                                            accept="image/png, image/jpeg, image/jpg"
                                            onChange={handleChange}
                                        />
                                        {errors.image && (
                                            <div className="text-danger mt-1">
                                                {errors.image.map((error, index) => (
                                                    <small key={index}>{error}</small>
                                                ))}
                                            </div>
                                        )}
                                    </div>
                                </div>

                                {/* Saqlash tugmasi */}
                                <button type="submit" className="btn btn-success w-100 custom-btn">
                                    <i className="fa-solid fa-floppy-disk me-2"></i> Saqlash
                                </button>

                                {/* Ortga tugmasi */}
                                <Link to="/users/profile" className="btn btn-secondary w-100 mt-3 custom-btn-secondary">
                                    <i className="fa-solid fa-arrow-left me-2"></i> Ortga
                                </Link>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default EditProfile;