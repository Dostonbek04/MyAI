import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import '../style/ProfilePayments.css';

const ProfilePayments = () => {
    const [user, setUser] = useState({
        username: '',
        email: '',
        profile: { image: { url: '/media/default/default_profile.png' } },
    });
    const [payments, setPayments] = useState([]);
    const [filter, setFilter] = useState('all');

    // Foydalanuvchi ma'lumotlari va to‘lovlarni olish
    useEffect(() => {
        const fetchData = async () => {
            try {
                const userResponse = await axios.get('/users/profile/', {
                    headers: { 'X-Requested-With': 'XMLHttpRequest' },
                });
                setUser(userResponse.data.user);

                const paymentsResponse = await axios.get('/payments/profile_payments/', {
                    headers: { 'X-Requested-With': 'XMLHttpRequest' },
                });
                setPayments(paymentsResponse.data.payments || []);
            } catch (err) {
                console.error('Xato:', err);
            }
        };

        fetchData();

        // Dark/Light tema sinxronizatsiyasi
        const currentTheme = localStorage.getItem('theme') || 'light';
        document.documentElement.setAttribute('data-theme', currentTheme);
    }, []);

    // Filtrlash logikasi
    const handleFilter = (filterValue) => {
        setFilter(filterValue);
    };

    const filteredPayments = filter === 'all' ? payments : payments.filter((payment) => payment.status === filter);

    return (
        <div className="container py-5">
            <div className="row">
                {/* Chap menyu - Profil va balans */}
                <div className="col-md-3">
                    <div className="card shadow-lg border-0 rounded-lg p-3 text-center">
                        <img
                            src={user.profile.image.url || '/media/default/default_profile.png'}
                            alt="Profil rasmi"
                            className="rounded-circle mb-3 profile-image"
                            width="100"
                        />
                        <h4 className="fw-bold">{user.username}</h4>
                        <p className="text-muted">{user.email}</p>
                        <Link
                            to="/users/profile"
                            className="btn btn-outline-primary btn-sm w-100 custom-btn-secondary"
                        >
                            <i className="fa-solid fa-arrow-left me-2"></i> Profilga qaytish
                        </Link>
                    </div>
                </div>

                {/* O'ng menyu - To‘lovlar */}
                <div className="col-md-9">
                    <div className="card shadow-lg border-0 rounded-lg">
                        <div className="card-header text-center">
                            <h3 className="card-title fw-bold">
                                <i className="fa-solid fa-history me-2"></i> To‘lov Tarixi
                            </h3>
                        </div>
                        <div className="card-body">
                            {/* Filtrlash qismi */}
                            <div className="mb-4 text-center">
                                <button
                                    className={`btn filter-btn ${filter === 'all' ? 'active' : ''}`}
                                    onClick={() => handleFilter('all')}
                                >
                                    <i className="fa-solid fa-th-large me-1"></i> Hammasi
                                </button>
                                <button
                                    className={`btn filter-btn ${filter === 'pending' ? 'active' : ''}`}
                                    onClick={() => handleFilter('pending')}
                                >
                                    <i className="fa-solid fa-hourglass-half me-1"></i> Kutilmoqda
                                </button>
                                <button
                                    className={`btn filter-btn ${filter === 'approved' ? 'active' : ''}`}
                                    onClick={() => handleFilter('approved')}
                                >
                                    <i className="fa-solid fa-check-circle me-1"></i> Tasdiqlangan
                                </button>
                                <button
                                    className={`btn filter-btn ${filter === 'rejected' ? 'active' : ''}`}
                                    onClick={() => handleFilter('rejected')}
                                >
                                    <i className="fa-solid fa-times-circle me-1"></i> Rad etilgan
                                </button>
                            </div>

                            {/* To‘lovlar ro‘yxati */}
                            <div className="row">
                                {filteredPayments.length > 0 ? (
                                    filteredPayments.map((payment, index) => (
                                        <div
                                            key={index}
                                            className="col-md-6 mb-4 payment-card"
                                            data-status={payment.status}
                                        >
                                            <div className="card shadow-sm border-0 rounded-lg p-3 payment-card-inner">
                                                <h5 className="fw-bold">
                                                    <i className="fa-solid fa-money-bill-wave me-2"></i>{' '}
                                                    {payment.amount} UZS
                                                </h5>
                                                <p className="text-muted mb-2">
                                                    <i className="date-sana fa-solid fa-calendar-alt me-1"></i>{' '}
                                                    {new Date(payment.created_at).toLocaleString()}
                                                </p>
                                                <span className="badge">
                                                    {payment.status === 'pending' && (
                                                        <>
                                                            <i className="fa-solid fa-hourglass-half me-1"></i>{' '}
                                                            Kutilmoqda
                                                        </>
                                                    )}
                                                    {payment.status === 'approved' && (
                                                        <>
                                                            <i className="fa-solid fa-check-circle me-1"></i>{' '}
                                                            Tasdiqlangan
                                                        </>
                                                    )}
                                                    {payment.status === 'rejected' && (
                                                        <>
                                                            <i className="fa-solid fa-times-circle me-1"></i>{' '}
                                                            Rad etilgan
                                                        </>
                                                    )}
                                                </span>
                                            </div>
                                        </div>
                                    ))
                                ) : (
                                    <div className="col-md-12 text-center py-4">
                                        <p className="text-muted">
                                            <i className="fa-solid fa-exclamation-circle me-1"></i> Sizda hali
                                            to‘lovlar mavjud emas.
                                        </p>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ProfilePayments;