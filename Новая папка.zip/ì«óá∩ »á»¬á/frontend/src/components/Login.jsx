import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import '../style/login.css'; // CSS faylini ulaymiz

const Login = () => {
    const [formData, setFormData] = useState({
        username: '',
        password: '',
    });
    const [errors, setErrors] = useState(null);
    const [showPassword, setShowPassword] = useState(false);
    const navigate = useNavigate();

    // Forma maydonlarini yangilash
    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };

    // Parolni ko‘rsatish/yashirish
    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword);
    };

    // Forma yuborilganda
    const handleSubmit = async (e) => {
        e.preventDefault();
        setErrors(null);

        try {
            const response = await axios.post('/users/login/', formData, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRFToken': getCsrfToken(), // CSRF tokenni olish
                },
            });
            // Muvaffaqiyatli kirishdan so‘ng yo‘naltirish
            navigate('/users/profile'); // Profilingiz sahifasiga yo‘naltirish
        } catch (err) {
            if (err.response && err.response.data) {
                setErrors(err.response.data.message || 'Foydalanuvchi nomi yoki parol noto‘g‘ri. Iltimos, qayta urinib ko‘ring.');
            } else {
                setErrors('Server bilan bog‘lanishda xato yuz berdi.');
            }
        }
    };

    // CSRF tokenni olish funksiyasi
    const getCsrfToken = () => {
        const name = 'csrftoken';
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    };

    // Dark/Light tema sinxronizatsiyasi
    useEffect(() => {
        const currentTheme = localStorage.getItem('theme') || 'light';
        document.documentElement.setAttribute('data-theme', currentTheme);
    }, []);

    return (
        <div className="container d-flex justify-content-center align-items-center min-vh-80">
            <div className="col-md-5">
                <div className="card shadow-lg rounded-lg fade-in">
                    <div className="card-header text-center py-4">
                        <h3 className="card-title fw-bold">
                            <i className="fa-solid fa-right-to-bracket me-2"></i>Hisobingizga kiring
                        </h3>
                    </div>
                    <div className="card-body p-4">
                        {/* Xatolik xabarlari */}
                        {errors && (
                            <div className="alert alert-danger alert-dismissible fade show" role="alert">
                                <i className="fa-solid fa-exclamation-triangle me-2"></i>{errors}
                                <button
                                    type="button"
                                    className="btn-close"
                                    data-bs-dismiss="alert"
                                    aria-label="Close"
                                    onClick={() => setErrors(null)}
                                ></button>
                            </div>
                        )}

                        {/* Kirish formasi */}
                        <form onSubmit={handleSubmit}>
                            <div className="mb-3">
                                <label className="form-label fw-bold">
                                    <i className="fa-solid fa-user me-2"></i>Foydalanuvchi nomi
                                </label>
                                <input
                                    type="text"
                                    name="username"
                                    className="form-control"
                                    placeholder="Username"
                                    value={formData.username}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                            <div className="mb-3 position-relative">
                                <label className="form-label fw-bold">
                                    <i className="fa-solid fa-lock me-2"></i>Parol
                                </label>
                                <div className="input-group">
                                    <input
                                        type={showPassword ? 'text' : 'password'}
                                        name="password"
                                        id="password"
                                        className="form-control"
                                        placeholder="*******"
                                        value={formData.password}
                                        onChange={handleChange}
                                        required
                                    />
                                    <button
                                        className="btn btn-outline-secondary toggle-password"
                                        type="button"
                                        onClick={togglePasswordVisibility}
                                    >
                                        <i className={`fa-solid ${showPassword ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                                    </button>
                                </div>
                            </div>
                            <button type="submit" className="btn btn-primary w-100 custom-btn">
                                <i className="fa-solid fa-rocket me-2"></i>Kirish
                            </button>
                        </form>

                        {/* Parolni unutdingizmi? va Ro‘yxatdan o‘tish */}
                        <div className="text-center mt-3">
                            <Link to="/users/password-reset" className="text-muted reset-link">
                                <i className="fa-solid fa-rotate me-1"></i>Parolni unutdingizmi?
                            </Link>
                            <p className="mt-2">
                                Yangi foydalanuvchimisiz?{' '}
                                <Link to="/users/register" className="register-link">
                                    Ro‘yxatdan o‘ting
                                </Link>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Login;