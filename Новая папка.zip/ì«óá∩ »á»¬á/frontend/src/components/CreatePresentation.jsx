import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import '../style/CreatePresentation.css';

const CreatePresentation = () => {
    const navigate = useNavigate();
    const [topic, setTopic] = useState('');
    const [subject, setSubject] = useState('');
    const [listCount, setListCount] = useState('8');
    const [withImages, setWithImages] = useState(false);
    const [titles, setTitles] = useState([]);
    const [editingIndex, setEditingIndex] = useState(null);
    const [editValue, setEditValue] = useState('');
    const [loading, setLoading] = useState(false);
    const [overlayLoading, setOverlayLoading] = useState(false);
    const [errorMessage, setErrorMessage] = useState('');
    const [showModal, setShowModal] = useState(false);

    // LocalStorage’dan ma'lumotlarni yuklash
    useEffect(() => {
        const savedData = localStorage.getItem('presentationData');
        if (savedData) {
            const data = JSON.parse(savedData);
            setTopic(data.topic || '');
            setSubject(data.subject || '');
            setListCount(data.list_count || '8');
            setWithImages(data.with_images || false);
            setTitles(data.titles || []);
        }
    }, []);

    // Tugma ko‘rinishini yangilash
    const updateGenerateButtonVisibility = () => {
        const isTopicFilled = topic.trim() !== '';
        const isSubjectFilled = subject.trim() !== '';
        const hasTitles = titles.length > 0;
        return isTopicFilled && isSubjectFilled && !hasTitles;
    };

    // Sarlavhalarni yaratish yoki qayta yaratish
    const regenerateTitles = async () => {
        setLoading(true);
        setOverlayLoading(true);
        setErrorMessage('');

        try {
            // 1-qadam: Ma'lumotlarni saqlash uchun create_presentation URL’ga so‘rov
            const formData = new FormData();
            formData.append('topic', topic);
            formData.append('subject', subject);
            formData.append('list_count', listCount);
            formData.append('with_images', withImages.toString());
            formData.append('csrfmiddlewaretoken', getCsrfToken());

            const saveResponse = await fetch('/presentations/create/', {
                method: 'POST',
                body: formData,
            });

            if (!saveResponse.ok) {
                throw new Error('Ma\'lumotlarni saqlashda xato yuz berdi');
            }

            // 2-qadam: Sarlavhalarni generatsiya qilish uchun generate_titles URL’ga so‘rov
            const generateResponse = await fetch('/presentations/generate_titles/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCsrfToken(),
                },
                body: JSON.stringify({}),
            });

            const data = await generateResponse.json();
            if (data.error) {
                throw new Error(data.error);
            }

            setTitles(data.titles);

            // LocalStorage’ni yangilash
            const presentationData = {
                topic,
                subject,
                list_count: listCount,
                with_images: withImages,
                titles: data.titles,
            };
            localStorage.setItem('presentationData', JSON.stringify(presentationData));
        } catch (error) {
            setErrorMessage(error.message || 'Sarlavhalarni generatsiya qilishda xato yuz berdi.');
            console.error('Xato:', error);
        } finally {
            setLoading(false);
            setOverlayLoading(false);
            setShowModal(false);
        }
    };

    // Tahrirlashni boshlash
    const handleEdit = (index, title) => {
        setEditingIndex(index);
        setEditValue(title);
    };

    // Tahrirni saqlash
    const handleSave = (index) => {
        const updatedTitles = [...titles];
        updatedTitles[index] = editValue;
        setTitles(updatedTitles);
        setEditingIndex(null);

        // LocalStorage’ni yangilash
        const presentationData = {
            topic,
            subject,
            list_count: listCount,
            with_images: withImages,
            titles: updatedTitles,
        };
        localStorage.setItem('presentationData', JSON.stringify(presentationData));
    };

    // Keyingi qadamga o‘tish
    const handleNext = async (e) => {
        e.preventDefault();

        const formData = new FormData();
        titles.forEach(title => formData.append('titles', title));
        formData.append('csrfmiddlewaretoken', getCsrfToken());

        try {
            const response = await fetch('/presentations/save_titles/', {
                method: 'POST',
                body: formData,
            });

            if (!response.ok) {
                throw new Error('Sarlavhalarni saqlashda xato yuz berdi');
            }

            navigate('/presentations/select-template/');
        } catch (error) {
            setErrorMessage(error.message || 'Keyingi qadamga o‘tishda xato yuz berdi.');
            console.error('Xato:', error);
        }
    };

    // CSRF tokenini olish
    const getCsrfToken = () => {
        const name = 'csrftoken';
        const cookies = document.cookie.split(';');
        for (let cookie of cookies) {
            cookie = cookie.trim();
            if (cookie.startsWith(name + '=')) {
                return cookie.substring(name.length + 1);
            }
        }
        return '';
    };

    return (
        <div className="container py-5">
            <div className="row justify-content-center">
                <div className="col-md-8">
                    <div className="card shadow-lg border-0 rounded-lg">
                        <div className="card-header text-center py-4">
                            <h2 className="fw-bold">
                                <i className="fa-solid fa-chalkboard-user me-2"></i> Yangi Taqdimot Yaratish - 1-qadam
                            </h2>
                        </div>
                        <div className="card-body p-4">
                            {errorMessage && (
                                <div className="alert alert-danger alert-dismissible fade show" role="alert">
                                    {errorMessage}
                                    <button type="button" className="btn-close" onClick={() => setErrorMessage('')}></button>
                                </div>
                            )}

                            <form id="presentation-form" onSubmit={handleNext}>
                                <div className="d-flex justify-content-between mb-4">
                                    <div>
                                        <label className="form-label fw-bold">
                                            <i className="fa-solid fa-list me-2"></i>Listlar soni
                                        </label>
                                        <select
                                            name="list_count"
                                            id="list_count"
                                            className="form-select form-select-sm"
                                            value={listCount}
                                            onChange={(e) => setListCount(e.target.value)}
                                            required
                                        >
                                            <option value="8">8 cards</option>
                                            <option value="10">10 cards</option>
                                            <option value="15">15 cards</option>
                                            <option value="20">20 cards</option>
                                            <option value="25">25 cards</option>
                                            <option value="30">30 cards</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label className="form-label fw-bold">
                                            <i className="fa-solid fa-image me-2"></i>Rasmlar bilanmi?
                                        </label>
                                        <select
                                            name="with_images"
                                            id="with_images"
                                            className="form-select form-select-sm"
                                            value={withImages ? 'true' : 'false'}
                                            onChange={(e) => setWithImages(e.target.value === 'true')}
                                        >
                                            <option value="false">Rasmsiz</option>
                                            <option value="true">Rasmli</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label className="form-label fw-bold">
                                            <i className="fa-solid fa-globe me-2"></i>Til tanlash
                                        </label>
                                        <select
                                            name="language"
                                            id="language"
                                            className="form-select form-select-sm"
                                            disabled
                                        >
                                            <option value="uz" selected>O‘zbek tili</option>
                                        </select>
                                    </div>
                                </div>

                                <div className="mb-4 position-relative topic-subject-container">
                                    <div className="topic-field me-2">
                                        <label className="form-label fw-bold">
                                            <i className="fa-solid fa-book me-2"></i>Mavzu
                                        </label>
                                        <input
                                            type="text"
                                            name="topic"
                                            id="topic"
                                            className="form-control"
                                            placeholder="Masalan: Son suyagi umumiy tafsilotlar"
                                            value={topic}
                                            onChange={(e) => setTopic(e.target.value)}
                                            required
                                        />
                                    </div>
                                    <div className="subject-field">
                                        <label className="form-label fw-bold">
                                            <i className="fa-solid fa-flask me-2"></i>Fan
                                        </label>
                                        <input
                                            type="text"
                                            name="subject"
                                            id="subject"
                                            className="form-control"
                                            placeholder="Masalan: Anatomiya yoki Matematika"
                                            value={subject}
                                            onChange={(e) => setSubject(e.target.value)}
                                            required
                                        />
                                    </div>
                                    <div className="regenerate-btn-container">
                                        <button
                                            type="button"
                                            className={`btn btn-sm regenerate-btn ${titles.length > 0 ? '' : 'd-none'}`}
                                            onClick={() => setShowModal(true)}
                                            title="Yangi sarlavhalar yaratish"
                                        >
                                            <i className="bi bi-arrow-repeat"></i>
                                        </button>
                                    </div>
                                </div>

                                <div className="text-center mb-4">
                                    <button
                                        type="button"
                                        className={`btn btn-lg custom-btn ${updateGenerateButtonVisibility() ? '' : 'd-none'}`}
                                        onClick={regenerateTitles}
                                        disabled={loading}
                                    >
                                        <span className={`button-text ${loading ? 'd-none' : ''}`}>
                                            <i className="fa-solid fa-magic-wand-sparkles me-2"></i>Sarlavhalar Yaratish
                                        </span>
                                        <span className={`loading-spinner ${loading ? '' : 'd-none'}`}>
                                            <span className="spinner-border spinner-border-sm pulse" role="status" aria-hidden="true"></span>
                                            Yuklanmoqda...
                                        </span>
                                    </button>
                                </div>

                                <div className={`mb-4 titles-section ${titles.length > 0 ? '' : 'd-none'}`}>
                                    <label className="form-label fw-bold">
                                        <i className="fa-solid fa-list-check me-2"></i>Outline
                                    </label>
                                    <div id="titles-list">
                                        {titles.map((title, index) => (
                                            <div
                                                key={index}
                                                className="mb-3 p-3 title-card fade-in-up"
                                                style={{ animationDelay: `${index * 0.1}s` }}
                                            >
                                                <div className="d-flex justify-content-between align-items-center">
                                                    <h5 className="mb-0">
                                                        {index + 1}.{' '}
                                                        {editingIndex === index ? (
                                                            <span className="title-text d-none">{title}</span>
                                                        ) : (
                                                            <span className="title-text">{title}</span>
                                                        )}
                                                    </h5>
                                                    {editingIndex === index ? null : (
                                                        <button
                                                            type="button"
                                                            className="btn btn-sm edit-btn"
                                                            onClick={() => handleEdit(index, title)}
                                                        >
                                                            <i className="bi bi-pencil"></i>
                                                        </button>
                                                    )}
                                                </div>
                                                <div className={`edit-input mt-2 ${editingIndex === index ? '' : 'd-none'}`}>
                                                    <input
                                                        type="text"
                                                        className="form-control edit-title-input"
                                                        value={editValue}
                                                        onChange={(e) => setEditValue(e.target.value)}
                                                        required
                                                    />
                                                    <button
                                                        type="button"
                                                        className="btn btn-sm save-btn mt-2"
                                                        onClick={() => handleSave(index)}
                                                    >
                                                        Saqlash
                                                    </button>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>

                                <div className="text-center">
                                    <button
                                        type="submit"
                                        className={`btn btn-lg custom-btn ${titles.length > 0 ? '' : 'd-none'}`}
                                    >
                                        <i className="fa-solid fa-arrow-right me-2"></i>Keyingi
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            {/* Modal oynasi */}
            <div
                className={`modal fade ${showModal ? 'show' : ''}`}
                style={{ display: showModal ? 'block' : 'none' }}
                tabIndex="-1"
                aria-labelledby="confirmRegenerateModalLabel"
                aria-hidden={!showModal}
            >
                <div className="modal-dialog modal-dialog-centered">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="confirmRegenerateModalLabel">
                                <i className="fa-solid fa-sync-alt me-2"></i>Yangi sarlavhalar yaratish
                            </h5>
                            <button
                                type="button"
                                className="btn-close"
                                onClick={() => setShowModal(false)}
                            ></button>
                        </div>
                        <div className="modal-body">
                            <p>Hozirgi sarlavhalar o‘chiriladi va yangi sarlavhalar yaratiladi. Davom etishni xohlaysizmi?</p>
                        </div>
                        <div className="modal-footer">
                            <button
                                type="button"
                                className="btn btn-secondary"
                                onClick={() => setShowModal(false)}
                            >
                                Yo‘q
                            </button>
                            <button
                                type="button"
                                className="btn btn-primary"
                                onClick={regenerateTitles}
                            >
                                Ha
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            {showModal && <div className="modal-backdrop fade show"></div>}

            {/* Loading overlay */}
            <div className={`loading-overlay ${overlayLoading ? '' : 'd-none'}`}>
                <div className="loading-spinner-overlay">
                    <div className="spinner-border spinner-border-lg text-primary" role="status">
                        <span className="visually-hidden">Yuklanmoqda...</span>
                    </div>
                    <p className="mt-2">Yuklanmoqda...</p>
                </div>
            </div>
        </div>
    );
};

export default CreatePresentation;