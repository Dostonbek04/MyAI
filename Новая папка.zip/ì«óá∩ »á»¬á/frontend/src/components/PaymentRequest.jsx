import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../style/PaymentRequest.css';

const PaymentRequest = () => {
    const [cardNumber, setCardNumber] = useState('');
    const [formData, setFormData] = useState({
        amount: '',
        receipt: null,
    });
    const [errors, setErrors] = useState({});
    const [message, setMessage] = useState('');
    const navigate = useNavigate();

    // Backend'dan karta raqamini olish va tema sinxronizatsiyasi
    useEffect(() => {
        const fetchCardNumber = async () => {
            try {
                const response = await axios.get('/payments/request/', {
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'Authorization': `Bearer ${localStorage.getItem('token')}`,
                    },
                });
                if (response.data.success) {
                    setCardNumber(response.data.card_number || '1234-5678-9012-3456');
                } else {
                    setCardNumber('1234-5678-9012-3456'); // Default qiymat
                }
            } catch (err) {
                console.error('Karta raqamini olishda xato:', err);
                setCardNumber('1234-5678-9012-3456'); // Default qiymat
            }
        };

        fetchCardNumber();

        // Dark/Light tema sinxronizatsiyasi
        const currentTheme = localStorage.getItem('theme') || 'light';
        document.documentElement.setAttribute('data-theme', currentTheme);
    }, []);

    // Forma o‘zgarishlarini boshqarish
    const handleChange = (e) => {
        const { name, value, files } = e.target;
        if (name === 'receipt') {
            setFormData({ ...formData, receipt: files[0] });
        } else {
            setFormData({ ...formData, [name]: value });
        }
    };

    // CSRF tokenni olish
    const getCsrfToken = () => {
        const name = 'csrftoken';
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    };

    // Formani yuborish
    const handleSubmit = async (e) => {
        e.preventDefault();
        setErrors({});
        setMessage('');

        const data = new FormData();
        data.append('amount', formData.amount);
        if (formData.receipt) {
            data.append('receipt', formData.receipt);
        }

        try {
            const response = await axios.post('/payments/request/', data, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRFToken': getCsrfToken(),
                    'Content-Type': 'multipart/form-data',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`,
                },
            });
            setMessage('✅ To‘lov so‘rovi muvaffaqiyatli yuborildi!');
            setErrors({});
            setFormData({ amount: '', receipt: null });
            document.getElementById('receipt').value = ''; // Fayl inputini tozalash
            if (response.data.redirect_url) {
                setTimeout(() => navigate(response.data.redirect_url), 2000);
            }
        } catch (err) {
            if (err.response && err.response.data) {
                if (err.response.data.errors) {
                    const parsedErrors = JSON.parse(err.response.data.errors);
                    setErrors(parsedErrors);
                } else {
                    setErrors(err.response.data);
                }
                setMessage('❌ Xatolik yuz berdi. Iltimos, qayta urinib ko‘ring.');
            } else {
                setMessage('❌ Server bilan bog‘lanishda xato yuz berdi!');
            }
        }
    };

    return (
        <div className="container d-flex justify-content-center align-items-center" style={{ minHeight: '80vh' }}>
            <div className="card shadow-lg p-4 border-0 rounded-lg" style={{ maxWidth: '500px', width: '100%' }}>
                <div className="card-body">
                    <h2 className="text-center text-primary fw-bold mb-4" style={{ fontSize: '1.8rem' }}>
                        <i className="fa-solid fa-credit-card me-2"></i> To‘lov So‘rovi
                    </h2>
                    <p className="text-center text-muted mb-4">
                        Iltimos, <strong>{cardNumber}</strong> kartasiga pul o‘tkazing va chekni yuklang.
                    </p>

                    {message && (
                        <div
                            className={`alert ${
                                message.includes('muvaffaqiyatli') ? 'alert-success' : 'alert-danger'
                            } alert-dismissible fade show`}
                            role="alert"
                        >
                            {message}
                            <button
                                type="button"
                                className="btn-close"
                                data-bs-dismiss="alert"
                                aria-label="Close"
                            ></button>
                        </div>
                    )}

                    <form onSubmit={handleSubmit} encType="multipart/form-data" className="mt-3">
                        {/* Miqdor */}
                        <div className="mb-4">
                            <label className="form-label fw-bold">
                                <i className="fa-solid fa-money-bill-wave me-1 text-success"></i> Miqdor (UZS)
                            </label>
                            <input
                                type="number"
                                name="amount"
                                id="amount"
                                className="form-control custom-input"
                                value={formData.amount}
                                onChange={handleChange}
                                required
                                min="1000"
                                placeholder="Minimal: 1000 UZS"
                            />
                            <small className="text-muted d-block mt-1">⚠ Minimal to‘lov summasi 1000 UZS</small>
                            {errors.amount && (
                                <div className="text-danger mt-1">
                                    {Array.isArray(errors.amount) ? (
                                        errors.amount.map((error, index) => (
                                            <small key={index}>{error}</small>
                                        ))
                                    ) : (
                                        <small>{errors.amount.message || errors.amount}</small>
                                    )}
                                </div>
                            )}
                        </div>

                        {/* Chek yuklash */}
                        <div className="mb-4">
                            <label className="form-label fw-bold">
                                <i className="fa-solid fa-camera me-1 text-primary"></i> Chek yuklang
                            </label>
                            <input
                                type="file"
                                name="receipt"
                                id="receipt"
                                className="form-control custom-input"
                                onChange={handleChange}
                                accept="image/png, image/jpeg, image/jpg"
                                required
                            />
                            <small className="text-muted d-block mt-1">⚠ Faqat PNG, JPG formatda (maks. 5MB)</small>
                            {errors.receipt && (
                                <div className="text-danger mt-1">
                                    {Array.isArray(errors.receipt) ? (
                                        errors.receipt.map((error, index) => (
                                            <small key={index}>{error}</small>
                                        ))
                                    ) : (
                                        <small>{errors.receipt.message || errors.receipt}</small>
                                    )}
                                </div>
                            )}
                        </div>

                        {/* Yuborish tugmasi */}
                        <button type="submit" className="btn btn-primary w-100 fw-bold custom-btn">
                            <i className="fa-solid fa-paper-plane me-2"></i> So‘rovni Yuborish
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default PaymentRequest;