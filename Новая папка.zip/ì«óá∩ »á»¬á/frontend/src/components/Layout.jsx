import React, { useState, useEffect } from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import axios from 'axios';
import Header from './Header';
import Footer from './Footer';
import NavButtons from './NavButtons';
import SystemMessages from './SystemMessages';
import ThemeToggle from './ThemeToggle';

function Layout() {
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const location = useLocation();
    const navigate = useNavigate();

    useEffect(() => {
        axios.get('/api/users/check-auth/')
            .then(response => {
                setIsAuthenticated(response.data.is_authenticated);
                // Agar foydalanuvchi autentifikatsiya qilingan bo‘lsa va profil sahifasida bo‘lmasa, profilga yo‘naltirish
                if (response.data.is_authenticated && location.pathname !== '/users/profile/') {
                    navigate('/users/profile/');
                }
            })
            .catch(error => {
                console.error('Autentifikatsiya holatini tekshirishda xatolik:', error);
                setIsAuthenticated(false);
            });
    }, [location, navigate]);

    return (
        <div>
            <Header />
            <div className="container mt-4">
                <Outlet />
            </div>
            <NavButtons />
            <SystemMessages />
            <ThemeToggle />
            <Footer />
        </div>
    );
}

export default Layout;