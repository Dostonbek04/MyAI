import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useNavigate } from 'react-router-dom';
import axios from 'axios';

// Barcha komponentlarni import qilamiz
import ChangePassword from './components/ChangePassword';
import CreatePresentation from './components/CreatePresentation';
import EditPresentation from './components/EditPresentation';
import EditProfile from './components/EditProfile';
import FeedbackForm from './components/FeedbackForm';
import Footer from './components/Footer';
import Header from './components/Header';
import Home from './components/Home';
import Login from './components/Login';
import NavButtons from './components/NavButtons';
import PaymentRequest from './components/PaymentRequest';
import PrivacyPolicy from './components/PrivacyPolicy';
import Profile from './components/Profile';
import Register from './components/Register';
import SelectTemplate from './components/SelectTemplate';
import SystemMessages from './components/SystemMessages';
import TermsOfService from './components/TermsOfService';
import ThemeToggle from './components/ThemeToggle';

// AppContent komponenti: Backend’dan javobni tekshirib, /home ga yo‘naltiradi
const AppContent = () => {
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    useEffect(() => {
        const checkBackend = async () => {
            try {
                console.log('Backend so‘rovini yuboryapman...');
                const response = await axios.get('/', {
                    headers: { 'X-Requested-With': 'XMLHttpRequest' },
                });
                console.log('Backend’dan javob:', response.data);
                if (response.data.success) {
                    console.log('Success true, /home ga yo‘naltiryapman');
                    navigate('/home');
                } else {
                    console.log('Success false, /home ga yo‘naltiryapman');
                    navigate('/home'); // Agar success false bo‘lsa ham /home ga yo‘naltirish
                }
            } catch (err) {
                console.error('Backend bilan bog‘lanishda xato:', err.message);
                console.log('Xato bo‘lsa ham /home ga yo‘naltiryapman');
                navigate('/home'); // Xatolik bo‘lsa ham /home ga yo‘naltirish
            } finally {
                setLoading(false);
            }
        };

        checkBackend();
    }, [navigate]);

    if (loading) {
        return <div>Yuklanmoqda...</div>;
    }

    return null;
};

// Asosiy App komponenti
const App = () => {
    return (
        <Router>
            <div className="App">
                <Header />
                <ThemeToggle />
                <NavButtons />
                <Routes>
                    <Route path="/" element={<AppContent />} />
                    <Route path="/home" element={<Home />} />
                    <Route path="/users/register" element={<Register />} />
                    <Route path="/users/login" element={<Login />} />
                    <Route path="/users/profile" element={<Profile />} />
                    <Route path="/users/edit-profile" element={<EditProfile />} />
                    <Route path="/users/change-password" element={<ChangePassword />} />
                    <Route path="/terms-of-service" element={<TermsOfService />} />
                    <Route path="/privacy-policy" element={<PrivacyPolicy />} />
                    <Route path="/payments/request" element={<PaymentRequest />} />
                    <Route path="/payments/request-payment" element={<PaymentRequest />} />
                    <Route path="/feedback/submit" element={<FeedbackForm />} />
                    <Route path="/feedback/feedback-view" element={<FeedbackForm />} />
                    <Route path="/presentations/create" element={<CreatePresentation />} />
                    <Route path="/presentations/edit/:id" element={<EditPresentation />} />
                    <Route path="/presentations/select-template" element={<SelectTemplate />} />
                    <Route path="/system-messages" element={<SystemMessages />} />
                    <Route path="/presentations/create-presentation" element={<CreatePresentation />} />
                </Routes>
                <Footer />
            </div>
        </Router>
    );
};

export default App;