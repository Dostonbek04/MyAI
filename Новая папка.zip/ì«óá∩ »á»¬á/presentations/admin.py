from django.contrib import admin
from .models import Presentation

# Presentation modelini ro'yxatdan o'tkazish
admin.site.register(Presentation)
